<?php
	session_start();
	print_r($_SESSION['eid']);
	$emp_id = $_SESSION['eid'];
	//print_r($_POST);
	error_reporting(E_ERROR | E_PARSE);

	echo $_GET['sr'];
	echo $_GET['tableID'];
	$sr = $_GET['sr'];
	$tab = $_GET['tableID'];
	$conn = mysqli_connect("localhost" , "root" ,"");
		if(!$conn)
	{echo "error in connection";}
	else
	{echo " connection established";} 

	mysqli_select_db($conn,"college");
	// if($tab=="table2"){
		echo "hii";
		//$table="qualific_details";
		$query = "DELETE from $tab where Sr_no='$sr'";
			echo($query);
			//echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in $tab inserted";
			}
			else
			{
				echo "error in '".$tab."' insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}

	// }
	// else{
	// 	$table="paper_publication";
	// 	$query = "delete from paper_publication where Sr_no='".$sr."'";
	// 		echo($query);
	// 		//echo("<br>");

	// 		if(mysqli_query($conn,$query))
	// 		{
	// 			echo "row in paper_publication inserted";
	// 		}
	// 		else
	// 		{
	// 			echo "error in paper_publication insertion";
	// 			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	// 		}
	// }
	//echo $table;
	//header( "refresh:1; url=check5.php" ); 
?>