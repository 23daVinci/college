<?php
include('account.php');
?>
<?php

//session_start();
//print_r($_SESSION['eid']);
$emp_id = $_SESSION['eid'];
//print_r($_POST);

if(isset($_POST['submit']))
{
	error_reporting(E_ERROR | E_PARSE);
	
	/* FILE UPLOADING BEGINS HERE */

	//print_r($_FILES);
	//echo "<br>";
	$file_count = count($_FILES);
	$tnc_proof_count = 0;
	$org_proof_count = 0;
	$ed_proof_count = 0;

	foreach ($_FILES as $key => $value) 
	{	
		if(strpos($key,'exp_details_') !== false)
		{
			$ed_proof_count++;
		}
		
		if(strpos($key,'train_conf_') !== false)
		{
			$tnc_proof_count++;
		}
		
		if(strpos($key,'organization_') !== false)
		{
			$org_proof_count++;
		}	
	}

	$img_arr = [];
	$type_identify = [];

	
	if($ed_proof_count>0)
	{
		for($itr=0; $itr<$ed_proof_count; $itr++)
		{
			array_push($img_arr, 'ed_proof'.($itr+1));
			array_push($type_identify, 'exp_details_'.($itr+1));
		}
	}
	

	
	if($tnc_proof_count>0)
	{
		for($itr=0; $itr<$tnc_proof_count; $itr++)
		{
			array_push($img_arr, 'tnc_proof'.($itr+1));
			array_push($type_identify, 'train_conf_'.($itr+1));
		}
	}

	if($org_proof_count>0)
	{
		for($itr=0; $itr<$org_proof_count; $itr++)
		{
			array_push($img_arr, 'org_proof'.($itr+1));
			array_push($type_identify, 'organization_'.($itr+1));
		}
	}
	foreach ($_FILES as $key => $value) 
	{
		echo($key." => ".$value);
	}

	for($i = 0; $i<$file_count; $i++) 
	{
		$target_dir = "uploads/";
		$target_file = $target_dir . basename($_FILES[$type_identify[$i]]["name"][0]);
		$path_parts = pathinfo($target_file);
		$file_extension = $path_parts['extension'];
		$saved_name = $target_dir.$img_arr[$i].'_'.$email.'.'.$file_extension;
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image
    	$check = getimagesize($_FILES[$type_identify[$i]]["tmp_name"][0]);
    	if($check !== false) 
    	{
        	echo "File is an image - " . $check["mime"] . ".<br>";
        	$uploadOk = 1;
    	} 
    	else 
    	{
        	echo "File is not an image.<br>";
        	$uploadOk = 0;
    	}
			// Check if file already exists
		if (file_exists($saved_name)) 
		{
    		echo "Sorry, file already exists.<br>";
    		$uploadOk = 0;
		}
			// Check file size
		if ($_FILES["fileToUpload"]["size"][$i] > 1000000) 
		{
    		echo "Sorry, your file is too large.<br>";
    		$uploadOk = 0;
		}
	
			// Allow certain file formats
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) 
		{
    		echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    		$uploadOk = 0;
		} 

		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) 
		{
    		echo "Sorry, your file was not uploaded.<br>";
		// if everything is ok, try to upload file
		}
		else 
		{
    		if (move_uploaded_file($_FILES[$type_identify[$i]]["tmp_name"][0],$saved_name)) 
    		{
        		echo "The file ". basename( $_FILES[$type_identify[$i]]["name"][$i]). " has been uploaded.<br>";
    		} 
    		else 
    		{
        		echo "Sorry, there was an error uploading your file.<br>";
    		}
		}
	}


	/* FILE UPLOADING FINISHES HERE */

	$non_empty = [];
	$final = [];

	foreach ($_POST as $key => $value) 
	{
		//echo($key);
		foreach ($value as $inner_key => $inner_value) 
		{
			if(!empty($inner_value))
			{	
				array_push($non_empty,$key);
				//print($inner_value);
				//print("&nbsp;");
				array_push($final, $inner_value);

			}
		}
		//echo("<br>");
	}
	/*
	echo "<br>";
	print_r($final);
	echo "<br><br>";
	print_r($non_empty);
	echo "<br><br>";
	*/
	$qualific_details = [];
	$exp_details = [];
	$appointment_details = [];
	$overall_exp_details = [];
	$subs_taught = [];
	$prof_memship = [];
	$interact_outside = [];
	$train_conf = [];
	$organization = [];
	$projects_guided = [];
	foreach ($non_empty as $key => $value) 
	{
		if(strpos($value,'qualific_details_') !== false)
		{
			array_push($qualific_details,$final[$key]);
			//print_r($qualific_details);
		}
		
		if(strpos($value,'teacher_exp_details_') !== false)
		{
			array_push($exp_details,$final[$key]);
			//print_r($exp_details);
		}
		if(strpos($value,'industry_exp_details_') !== false)
		{
			array_push($appointment_details,$final[$key]);
			//print_r($exp_details);
		}
		if(strpos($value,'research_exp_details_') !== false)
		{
			array_push($overall_exp_details,$final[$key]);
			// print_r("hiiiiii".$overall_exp_details);
						echo "<br><br>";
		}
		if(strpos($value,'subs_taught_') !== false)
		{
			array_push($subs_taught,$final[$key]);
		}

		if(strpos($value,'prof_memship_') !== false)
		{
			array_push($prof_memship,$final[$key]);
		}

		if(strpos($value,'interact_outside_') !== false)
		{
			array_push($interact_outside,$final[$key]);
		}

		if(strpos($value,'train_conf_') !== false)
		{
			array_push($train_conf,$final[$key]);
		}

		if(strpos($value,'organization_') !== false)
		{
			array_push($organization,$final[$key]);
		}

		if(strpos($value,'projects_guided_') !== false)
		{
			array_push($projects_guided,$final[$key]);
		}
	}
	// 	print_r($exp_details);
	// echo "<br><br>";

	// print_r($overall_exp_details);
	// echo "<br><br>";
	
	// print_r($qualific_details);
	// echo "<br><br>";

	// print_r($train_conf);
	// echo "<br><br>";

	// print_r($prof_memship);
	// echo "<br><br>";

	// print_r($interact_outside);
	// echo "<br><br>";

	// print_r($train_conf);
	// echo "<br><br>";

	// print_r($organization);
	// echo "<br><br>";

	// print_r($projects_guided);
	// echo "<br><br>";

	// print_r($appointment_details);
	// echo "<br><br>";
	
	// $qd_itr = 8;
	// $ed_itr = 4;
	// $ap_itr = 5;
	// $st_itr = 5;
	// $ot_itr = 3;
	// $pm_itr = 3;
	// $io_itr = 3;
	// $tc_itr = 5;
	// $org_itr = 3;
	// $pg_itr = 7;

	$qd_itr = 9;
	$ed_itr = 11;
	$ap_itr = 6;
	$st_itr = 6;
	$ot_itr = 6;
	$pm_itr = 4;
	$io_itr = 4;
	$tc_itr = 5;
	$org_itr = 4;
	$pg_itr = 8;

	$qd_rcount = count($qualific_details)/$qd_itr;
	$ed_rcount = count($exp_details)/$ed_itr;
	$ap_rcount = count($appointment_details)/$ap_itr;
	$ot_rcount = count($overall_exp_details)/$ot_itr;
	$st_rcount = count($subs_taught)/$st_itr;
	$pm_rcount = count($prof_memship)/$pm_itr;
	$io_rcount = count($interact_outside)/$io_itr;
	$tc_rcount = count($train_conf)/$tc_itr;
	$org_rcount = count($organization)/$org_itr;
	$pg_rcount = count($projects_guided)/$pg_itr;
	// echo "vimp";
	// 	print($tc_rcount);
	/*
	print($tc_rcount);
	print($qd_rcount);
	print($st_rcount);
	print($pm_rcount);
	print($io_rcount);
	print($tc_rcount);
	print($org_rcount);
	print($pg_rcount);
	echo "<br>";
	*/
	$conn = mysqli_connect("localhost" , "root" ,"");

	/*if(!$conn)
	{echo "error in connection";}
	else
	{echo " connection established";} */

	mysqli_select_db($conn,"college");

	
	// insert into qualification details
	if($qd_rcount > 0)
	{//echo "hii";
		for($curr_row = 1; $curr_row <= $qd_rcount; $curr_row++)
		{	
			${"qualific_details_$curr_row"} = [];
			for($i = ($qd_itr*($curr_row-1)); $i< ($qd_itr*($curr_row)) ; $i++)
			{
				array_push(${"qualific_details_$curr_row"}, $qualific_details[$i]);
				//echo $qualific_details[$i];
			}
		}

		for($i=1;$i<=$qd_rcount;$i++)
		{
			//print_r(${"qualific_details_$i"});
			//echo "<br>";
			$_SESSION["qd_$i"] = ${"qualific_details_$i"};
			$qd["$i"] = $_SESSION["qd_$i"]; 
		}
		for($i=1;$i<=$qd_rcount;$i++){
			$query = "insert into qualification_details(Sr_no,emp_id,qualification, branch, specialization, university, percentage, cgpa, class_obtained, passing_year) values ('".$qd["$i"][8]."','$emp_id','".$qd["$i"][0]."','".$qd["$i"][1]."','".$qd["$i"][2]."','".$qd["$i"][3]."','".$qd["$i"][4]."','".$qd["$i"][5]."','".$qd["$i"][6]."','".$qd["$i"][7]."') on duplicate key update Sr_no='".$qd["$i"][8]."', emp_id='$emp_id',qualification='".$qd["$i"][0]."', branch='".$qd["$i"][1]."', specialization='".$qd["$i"][2]."', university='".$qd["$i"][3]."', percentage='".$qd["$i"][4]."', cgpa='".$qd["$i"][5]."', class_obtained='".$qd["$i"][6]."', passing_year='".$qd["$i"][7]."'";
			//echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in qualification_details inserted";
			}
			else
			{
				echo "error in qualification_details insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}
// insert into qualification details ENDS

// insert into experience details
	if($ed_rcount > 0)
	{
		for($curr_row = 1; $curr_row <= $ed_rcount; $curr_row++)
		{	
			${"teacher_exp_details_$curr_row"} = [];
			for($i = ($ed_itr*($curr_row-1)); $i< ($ed_itr*($curr_row)) ; $i++)
			{
				array_push(${"teacher_exp_details_$curr_row"}, $exp_details[$i]);
			}
		}
                                   
		for($i=1;$i<=$ed_rcount;$i++)
		{
			//print_r(${"qualific_details_$i"});
			//echo "<br>";
			$_SESSION["ed_$i"] = ${"teacher_exp_details_$i"};
			$ed["$i"] = $_SESSION["ed_$i"]; 
		}

		for($i=1;$i<=$ed_rcount;$i++){
			$query = "insert into teacher_experience_details(emp_id,Sr_no,organization_name, designation, date_of_joining, last_date_of_working, current_pay_scale, grade_pay, nature_of_appointment, ussc_app_date, ussc_ref_no, teaching_exp_years) values ('$emp_id','".$ed["$i"][10]."','".$ed["$i"][0]."','".$ed["$i"][1]."','".$ed["$i"][2]."','".$ed["$i"][3]."','".$ed["$i"][4]."','".$ed["$i"][5]."','".$ed["$i"][6]."','".$ed["$i"][7]."','".$ed["$i"][8]."','".$ed["$i"][9]."') on duplicate key update emp_id='$emp_id',Sr_no='".$ed["$i"][10]."',organization_name='".$ed["$i"][0]."', designation='".$ed["$i"][1]."', date_of_joining='".$ed["$i"][2]."', last_date_of_working='".$ed["$i"][3]."', current_pay_scale='".$ed["$i"][4]."' , grade_pay='".$ed["$i"][5]."' ,nature_of_appointment='".$ed["$i"][6]."' ,ussc_app_date='".$ed["$i"][7]."' ,ussc_ref_no= '".$ed["$i"][8]."', teaching_exp_years= '".$ed["$i"][9]."'";
			//echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in teacher_exp_details inserted";
			}
			else
			{
				echo "error in teacher_exp_details insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}
// insert into experience details ENDS

//insert into appointment details
if($ap_rcount > 0)
	{
		for($curr_row = 1; $curr_row <= $ap_rcount; $curr_row++)
		{	
			${"industry_exp_details_$curr_row"} = [];
			for($i = ($ap_itr*($curr_row-1)); $i< ($ap_itr*($curr_row)) ; $i++)
			{
				array_push(${"industry_exp_details_$curr_row"}, $appointment_details[$i]);
			}
		}

		for($i=1;$i<=$ap_rcount;$i++)
		{
			//print_r(${"qualific_details_$i"});
			//echo "<br>";
			$_SESSION["ap_$i"] = ${"industry_exp_details_$i"};
			$ap["$i"] = $_SESSION["ap_$i"]; 
		}

		for($i=1;$i<=$ap_rcount;$i++){
			$query = "insert into industry_experience_details(Sr_no, emp_id,organization_name, designation, date_of_joining, last_date_of_working, industry_exp_years ) values ('".$ap["$i"][5]."','$emp_id','".$ap["$i"][0]."','".$ap["$i"][1]."','".$ap["$i"][2]."','".$ap["$i"][3]."','".$ap["$i"][4]."') on duplicate key update Sr_no='".$ap["$i"][5]."', emp_id='$emp_id', organization_name ='".$ap["$i"][0]."', designation='".$ap["$i"][1]."', date_of_joining='".$ap["$i"][2]."', last_date_of_working='".$ap["$i"][3]."', industry_exp_years ='".$ap["$i"][4]."'";
			// echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in industry_exp_details_ inserted";
			}
			else
			{
				echo "error in industry_exp_details_ insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}

//insert overall details

if($ot_rcount > 0)
	{//echo "hii";
		for($curr_row = 1; $curr_row <= $ot_rcount; $curr_row++)
		{	
			${"research_exp_details_$curr_row"} = [];
			for($i = ($ot_itr*($curr_row-1)); $i< ($ot_itr*($curr_row)) ; $i++)
			{
				array_push(${"research_exp_details_$curr_row"}, $overall_exp_details[$i]);
				//echo $overall_exp_details[$i];
			}
		}

		for($i=1;$i<=$ot_rcount;$i++)
		{
			// print_r(${"<br><br>qualific_details_$i"});
			//echo "<br>";
			$_SESSION["ot_$i"] = ${"research_exp_details_$i"};
			//echo "<br><br>".$overall_exp_details[$i];
			$ot["$i"] = $_SESSION["ot_$i"]; 
		}
		for($i=1;$i<=$ot_rcount;$i++){
			$query = "insert into research_experience_details(Sr_no, emp_id,organization_name, designation, date_of_joining, last_date_of_working, research_exp_years ) values ('".$ot["$i"][5]."','$emp_id','".$ot["$i"][0]."','".$ot["$i"][1]."','".$ot["$i"][2]."','".$ot["$i"][3]."','".$ot["$i"][4]."') on duplicate key update Sr_no='".$ot["$i"][5]."', emp_id='$emp_id', organization_name='".$ot["$i"][0]."', designation='".$ot["$i"][1]."', date_of_joining ='".$ot["$i"][2]."', last_date_of_working ='".$ot["$i"][3]."', research_exp_years ='".$ot["$i"][4]."' ";
			//echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in research_experience_details inserted";
			}
			else
			{
				echo "error in research_experience_details insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}

// insert into subject taught
	if($st_rcount > 0)
	{
		for($curr_row = 1; $curr_row <= $st_rcount; $curr_row++)
		{	
			${"subs_taught_$curr_row"} = [];
			for($i = ($st_itr*($curr_row-1)); $i< ($st_itr*($curr_row)) ; $i++)
			{
				array_push(${"subs_taught_$curr_row"}, $subs_taught[$i]);
			}
			//print_r(${"subs_taught_$curr_row"});
			//echo "<br>";
		}

		for($i=1;$i<=$st_rcount;$i++)
		{
			//print_r(${"subs_taught_$i"});
			//echo "<br>";
			$_SESSION["subs_taught_$i"] = ${"subs_taught_$i"};
			$st["$i"] = $_SESSION["subs_taught_$i"]; 
		}
		
		for($i=1;$i<=$st_rcount;$i++){
			$query = "insert into subject_taught(emp_id,Sr_no ,Type_of_graduation,Subject_taught,Peroid_Year,sub_exp,Syllabus) values ('$emp_id','".$st["$i"][5]."' ,'".$st["$i"][0]."','".$st["$i"][1]."','".$st["$i"][2]."','".$st["$i"][3]."','".$st["$i"][4]."') on duplicate key update emp_id='$emp_id',Sr_no='".$st["$i"][5]."',Type_of_graduation='".$st["$i"][0]."',Subject_taught='".$st["$i"][1]."',Peroid_Year='".$st["$i"][2]."',sub_exp='".$st["$i"][3]."',Syllabus='".$st["$i"][4]."'"; 
			//echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in subject_taught inserted";
			}
			else
			{
				echo "error in subject_taught insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}
// insert into subject taught ENDS


// insert into PROFESSIONAL MEMBERSHIP DETAILS
	if($pm_rcount > 0)
	{
		for($curr_row = 1; $curr_row <= $pm_rcount; $curr_row++)
		{	
			${"prof_memship_$curr_row"} = [];
			for($i = ($pm_itr*($curr_row-1)); $i< ($pm_itr*($curr_row)) ; $i++)
			{
				array_push(${"prof_memship_$curr_row"}, $prof_memship[$i]);
			}
			//print_r(${"prof_memship_$curr_row"});
			//echo "<br>";
		}

		for($i=1;$i<=$pm_rcount;$i++)
		{
			//print_r(${"prof_memship_$i"});
			//echo "<br>";
			$_SESSION["prof_memship_$i"] = ${"prof_memship_$i"};
			$pm["$i"] = $_SESSION["prof_memship_$i"];
		}
		
		for($i=1;$i<=$pm_rcount;$i++){
			$query = "insert into professional_membership(Sr_no, emp_id,Membership_category,Membership_no,Body_of_organization) values ('".$pm["$i"][3]."','$emp_id','".$pm["$i"][0]."','".$pm["$i"][1]."','".$pm["$i"][2]."') on duplicate key update Sr_no='".$pm["$i"][3]."', emp_id='$emp_id',Membership_category='".$pm["$i"][0]."',Membership_no='".$pm["$i"][1]."',Body_of_organization='".$pm["$i"][2]."'";
			//echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in professional_membership inserted";
			}
			else
			{
				echo "error in professional_membership insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}

// insert into PROFESSIONAL MEMBERSHIP DETAILS ends

// insert into interaction_with_outside_world
	if($io_rcount > 0)
	{
		for($curr_row = 1; $curr_row <= $io_rcount; $curr_row++)
		{	
			${"interact_outside_$curr_row"} = [];
			for($i = ($io_itr*($curr_row-1)); $i< ($io_itr*($curr_row)) ; $i++)
			{
				array_push(${"interact_outside_$curr_row"}, $interact_outside[$i]);
			}
			//print_r(${"interact_outside_$curr_row"});
			//echo "<br>";
		}

		for($i=1;$i<=$io_rcount;$i++)
		{
			//print_r(${"interact_outside_$i"});
			//echo "<br>";
			$_SESSION["interact_outside_$i"] = ${"interact_outside_$i"};
			$io["$i"] = $_SESSION["interact_outside_$i"];
		}
		
		for($i=1;$i<=$io_rcount;$i++){
			$query = "insert into interaction_with_outside_world(Sr_no , emp_id, Interaction_Type, Organization,Date ) values ( '".$io["$i"][3]."', '$emp_id' , '".$io["$i"][0]."','".$io["$i"][1]."','".$io["$i"][2]."') on duplicate key update Sr_no='".$io["$i"][3]."',emp_id='$emp_id',Interaction_Type='".$io["$i"][0]."',Organization='".$io["$i"][1]."',Date='".$io["$i"][2]."'";
			//echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in interaction_with_outside_world inserted";
			}
			else
			{
				echo "error in interaction_with_outside_world insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}
// insert into interaction_with_outside_world end

// insert into TRAINING COURSES/ SEMINAR/ WORKSHOP/ CONFERENCE ATTENDED

	if($tc_rcount > 0)
	{
		for($curr_row = 1; $curr_row <= $tc_rcount; $curr_row++)
		{	
			${"train_conf_$curr_row"} = [];
			for($i = ($tc_itr*($curr_row-1)); $i< ($tc_itr*($curr_row)) ; $i++)
			{
				array_push(${"train_conf_$curr_row"}, $train_conf[$i]);
			}
			//print_r(${"train_conf_$curr_row"});
			//echo "<br>";
		}

		for($i=1;$i<=$tc_rcount;$i++)
		{
			//print_r(${"train_conf_$i"});
			//echo "<br>";
			$_SESSION["train_conf_$i"] = ${"train_conf_$i"};
			$tc["$i"] = $_SESSION["train_conf_$i"];
		}
		
		for($i=1;$i<=$tc_rcount;$i++){
			$query = "insert into training_courses_attended(Sr_no, emp_id,course_name,organization_name,start_date,end_date) values ('".$tc["$i"][4]."','$emp_id','".$tc["$i"][0]."','".$tc["$i"][1]."','".$tc["$i"][2]."','".$tc["$i"][3]."') on duplicate key update Sr_no='".$tc["$i"][4]."',emp_id='$emp_id',course_name='".$tc["$i"][0]."', organization_name='".$tc["$i"][1]."', start_date='".$tc["$i"][2]."', end_date='".$tc["$i"][3]."'  ";
			//echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in training_courses_attended inserted";
			}
			else
			{
				echo "error in training_courses_attended insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}

// insert into TRAINING COURSES/ SEMINAR/ WORKSHOP/ CONFERENCE ATTENDED end 

// insert into TRAINING COURSES/ SEMINAR/ WORKSHOP/ CONFERENCE ORGANIZED

	if($org_rcount > 0)
	{
		for($curr_row = 1; $curr_row <= $org_rcount; $curr_row++)
		{	
			${"organization_$curr_row"} = [];
			for($i = ($org_itr*($curr_row-1)); $i< ($org_itr*($curr_row)) ; $i++)
			{
				array_push(${"organization_$curr_row"}, $organization[$i]);
			}
			//print_r(${"organization_$curr_row"});
			//echo "<br>";
		}

		for($i=1;$i<=$org_rcount;$i++)
		{
			//print_r(${"organization_$i"});
			//echo "<br>";
			$_SESSION["organization_$i"] = ${"organization_$i"};
			$org["$i"] = $_SESSION["organization_$i"];
		}
		
		for($i=1;$i<=$org_rcount;$i++){
			$query = "insert into training_courses_organize(emp_id,Sr_no,course_name,responsibility,course_duration) values ('$emp_id','".$org["$i"][3]."','".$org["$i"][0]."','".$org["$i"][1]."','".$org["$i"][2]."') on duplicate key update Sr_no='".$org["$i"][3]."', emp_id='$emp_id',Sr_no='".$org["$i"][3]."',course_name='".$org["$i"][0]."',responsibility='".$org["$i"][1]."',course_duration='".$org["$i"][2]."'";
			//echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in training_courses_organize inserted";
			}
			else
			{
				echo "error in training_courses_organize insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}
// insert into TRAINING COURSES/ SEMINAR/ WORKSHOP/ CONFERENCE ORGANIZED  end


// insert into PROJECT GUIDED


	if($pg_rcount > 0)
	{
		for($curr_row = 1; $curr_row <= $pg_rcount; $curr_row++)
		{	
			${"projects_guided_$curr_row"} = [];
			for($i = ($pg_itr*($curr_row-1)); $i< ($pg_itr*($curr_row)) ; $i++)
			{
				array_push(${"projects_guided_$curr_row"}, $projects_guided[$i]);
			}
			//print_r(${"projects_guided_$curr_row"});
			//echo "<br>";
		}

		for($i=1;$i<=$pg_rcount;$i++)
		{
			//print_r(${"projects_guided_$i"});
			//echo "<br>";
			$_SESSION["projects_guided_$i"] = ${"projects_guided_$i"};
			$pg["$i"] = $_SESSION["projects_guided_$i"];
		}
		
		for($i=1;$i<=$pg_rcount;$i++){
			$query = "insert into project_guided(Sr_no, emp_id, project_title, guide_name,group_members,dept,year,student_cat,remark) values ('".$pg["$i"][7]."','$emp_id','".$pg["$i"][0]."','".$pg["$i"][1]."','".$pg["$i"][2]."','".$pg["$i"][3]."','".$pg["$i"][4]."','".$pg["$i"][5]."','".$pg["$i"][6]."') on duplicate key update Sr_no='".$pg["$i"][7]."', emp_id='$emp_id', project_title='".$pg["$i"][0]."' ,guide_name='".$pg["$i"][1]."' , group_members='".$pg["$i"][2]."' , dept='".$pg["$i"][3]."' , year='".$pg["$i"][4]."',student_cat='".$pg["$i"][4]."' , remark='".$pg["$i"][6]."'";
			//echo($query);
			echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in project_guided inserted";
			}
			else
			{
				echo "error in project_guided insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
	}
// insert into PROJECT GUIDED end	
}

//echo "<br>Printing session variable now<br>";
//print_r($_SESSION);


?>
