<?php
include('account.php');
?>
<?php
//session_start();
//print_r($_SESSION);
$empid=$_SESSION['eid'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql= "SELECT * from designation where emp_id='$empid'";
$result = $conn->query($sql);

$count1 = 0;
$Sr_No1 =[];
$designation = [];

if ($result->num_rows > 0 ) {
while($row1 = $result->fetch_assoc()) {
    $Sr_No1[$count1]=$row1['Sr_no'];
    $designation[$count1]=$row1['designation'];
    $count1++;
 }
}
if (isset($_POST['SUB']) && isset($_POST['faculty_type']) && isset($_POST['appointment_type']) && isset($_POST['Dept_name']) && isset($_POST['highest_qualif'])) {
    $faculty_type = $_POST['faculty_type'];
    $appointment_type = $_POST['appointment_type'];
    $Dept_name = $_POST['Dept_name'];
    $college_emp_id = $_POST['college_emp_id'];
    $Library_card_no = $_POST['Library_card_no'];
    $highest_qualif= $_POST['highest_qualif'];


    $sql2 = "UPDATE staff_emp_details SET faculty_type = '$faculty_type',appointment_type = '$appointment_type',Dept_name = '$Dept_name',college_emp_id = '$college_emp_id',Library_card_no = '$Library_card_no', highest_qualif = '$highest_qualif' WHERE emp_id='$empid'";

    if ($conn->query($sql2) === TRUE) {
        echo "<br>Record updated successfully";
    } else {
        echo "Error: " . $sql2 . "<br>" . $conn->error;
    }
    # code...
}
    if(isset($_POST['SUB']) && isset($_POST['designation']))
    {   
        $emp_id = $_SESSION['eid'];
        $designation = $_POST['designation'];
        $q = "DELETE FROM designation WHERE emp_id='$emp_id'";
        $r = mysqli_query($conn,$q);

        if(!empty($_POST['other_designation']))
        {
            $other_designation = explode(',',$_POST['other_designation']);
            $designation = array_merge($designation,$other_designation);
            //print_r($responsibilities);
        }

        $conn = mysqli_connect("localhost" , "root" ,"");

        if(!$conn)
        {
            $code = 500;
            header("Location: alert.php?code=$code");
        }

        mysqli_select_db($conn,"college");
        //insert into other_designation
        foreach ($designation as $key => $value) 
        {
            $sql1 = "insert into designation (emp_id,designation) values('$emp_id','$value') ";

            $insert_result1 = mysqli_query($conn,$sql1);

            if($insert_result1)
            {
                //print("Submission Done");
            }
            else
            {
                $code = 500;
                header("Location: alert.php?code=$code");
            }
        }
        $sql= "SELECT * from designation where emp_id='$empid'";
        $result = $conn->query($sql);

        $count1 = 0;
        $Sr_No1 =[];
        $designation = [];

        if ($result->num_rows > 0 ) {
            while($row1 = $result->fetch_assoc()) {
                $Sr_No1[$count1]=$row1['Sr_no'];
                $designation[$count1]=$row1['designation'];
                $count1++;
            }
        }
    }
    else if(isset($_POST['SUB']) && !isset($_POST['designation'])){
        $emp_id = $_SESSION['eid'];
        $q = "DELETE FROM designation WHERE emp_id='$emp_id'";
        $r = mysqli_query($conn,$q);
         $sql= "SELECT * from designation where emp_id='$empid'";
        $result = $conn->query($sql);

        $count1 = 0;
        $Sr_No1 =[];
        $designation = [];

        if ($result->num_rows > 0 ) {
            while($row1 = $result->fetch_assoc()) {
                $Sr_No1[$count1]=$row1['Sr_no'];
                $designation[$count1]=$row1['designation'];
                $count1++;
            }
        }
    }

$sql= "SELECT * from staff_emp_details where emp_id='$empid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    echo "<div>
    <h2>
    STAFF EMPLOYMENT DETAILS</h2>
   </div>";
    while($row = $result->fetch_assoc()) {
        
        echo "
<form action='check2-1.php' method='post'>
        <table id='records' align='center'>

<tr>
    <th>Faculty Type :</th>
    <td>
        <select name='faculty_type' onchange='vis2(this)' required>
            <option selected='selected' id='faculty' value=".$row['faculty_type'].">".$row['faculty_type']."</option>
            <option value='teaching'>Teaching Staff</option>
            <option value='nonteaching'>Non Teaching Staff</option>
            <option value='admin'>Administration</option>       
        </select>
    </td>
</tr>
<tr> 
    <th>Appointment Type :</th>
    <td>
        <select name='appointment_type' required>
            <option selected='selected' value=".$row['appointment_type'].">".$row['appointment_type']."</option>
            <option value='ussg'>USSG Approved</option>
            <option value='reg'>Regular</option>
            <option value='adhoc'>Adhoc</option>        
        </select>
    </td>
</tr>
<tr>
<th> Department </th>
<td>
    <select name='Dept_name' required>
        <option selected='selected'  value=".$row['Dept_name'].">".$row['Dept_name']."</option>
        <option value='comp'>Computer Science</option>
        <option value='it'>Information Technology</option>
        <option value='extc'>Electronics And Telecommunication </option>        
        <option value='elec'>Electrical </option>
        <option value='mech'>Mechanical</option>
        <option value='hum'>Humanities </option>
    </select>
</td>
</tr>
<tr></tr>       
<tr> <th>Employee ID </th>
    <td><input type='text' name='college_emp_id' id='emid' required value=".$row['college_emp_id']."></td>
    </tr>
    <tr><th>Library Card Number </th>
    <td><input type='text' name='Library_card_no' id='libno' required value=".$row['Library_card_no']."></td>
    </tr>
    
<tr><th>Highest Qualification </th>
    <td><select name='highest_qualif' required>
        <option selected='selected' value=".$row['highest_qualif'].">".$row['highest_qualif']."</option>
        <option value='post_phd'>Post Ph.D (Specialization)</option>
        <option value='it'>Ph.D (Specialization)</option>
        <option value='mphil'>M.Phil (Specialization)</option>        
        <option value='me'>M.E (Specialization)</option>
        <option value='ms'>M.S (Specialization)</option>
        <option value='mtech'>M.Tech (Specialization) </option>
        <option value='msc'>M.Sc (Specialization) </option>
    <option value='ma'>M.A (Specialization) </option>
    <option value='be'>B.E (Specialization) </option>
    <option value='bs'>B.S (Specialization)</option>
    <option value='btech'>B.Tech (Specialization) </option>
    <option value='diploma'>Diploma (Specialization) </option>
    <option value='bsc'>B.Sc (Specialization) </option>
    <option value='ba'>B.A (Specialization) </option>
    
    </select>
</td>
    </tr>
    </table>     
           <center>
<br>
</center>";
} 
}
else {
    echo "0 results";
      header("Location: stage2-1.php");
}


$conn->close();
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
<style type="text/css">
.navbar {
    overflow: hidden;
    background-color: #DCDCDC;
    font-family: Arial;
}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: black;
    padding: 14px 16px;
    background-color: inherit;
    font: inherit;
    margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color:   #C0C0C0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 130px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}

#records {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 63%;

}

#records td, #records th {
    border: 1px solid #A9A9A9;
    padding: 8px;
}

#records th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #DCDCDC;
    color: black;
    width: 30%;
}
#records td {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: white;
    color: black;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}


hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 

body {
    font-family: "Lato", sans-serif;
    color:black;
}
	
</style>

</head>
<body align='center' onload="myFunc();">
<!-- <div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
 --> <!--   <br>
   <div>
   	<h2 align="center">
   	STAFF EMPLOYMENT DETAILS</h2>
   </div> -->
   <table id="desg_table">
 <caption><h2>Designation</h2></caption>
   <tr>
   <td  align="right"><input type="checkbox" name="designation[]" id="1" value="principal" id="ts"/></td>
   <td><label>Principal</label></td>
    </tr>
    
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" id="2" value="prof_hod" id="ts" /></td>
    <td><label>Professor and Head Of Department(HOD)</label></td>
    <!--ss=Senior Supervisior-->
    </tr>
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" id="3" value="prof_dean" id="ts" /></td>
    <td><label>Professor and Dean</label></td>
    <!--ei=Exam Cell Incharge-->
    </tr>
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" id="4" value="prof" id="ts" /></td>
    <td><label>Professor</label></td>
    <!--cmi=College Magzine Incharge--> 
    </tr>
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" id="5" value="assoc_prof_hod" id="ts" /></td>
    <td><label>Associate Professor and Head Of Department</label></td>
    <!--hod=Head Of Department--> 
    </tr>
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" id="6" value="assoc_prof_dean" id="ts" /></td>
    <td><label>Associate Professor and Dean</label></td>
    <!--c=Co-ordinator--> 
    </tr>
    <tr>
    <td  align="right"><input type="checkbox" name="designation[]" id="7" value="assoc_prof" id="ts" /></td>
    <td><label>Associate Professor</label></td>
    <!--coe=Controller of Examination--> 
    </tr>
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" id="8" value="ass_prof" id="ts" /></td>
    <td><label>Assistant Professor</label></td>
    <!--dcoe=Deputy Controller of Examination--> 
    </tr>
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" id="9" value="falicit_cnt_coord" id="ts" /></td>
    <td><label>Falicitaion Centre Co-ordinator</label></td>
    <!--fcc=Falicitaion Centre Co-ordinator--> 
    </tr>
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" id="10" value="fe_engg_adm" id="ts" /></td>
    <td><label>First Year Engineering Admission</label></td>
    <!--fcc=First Year Engineering Admission--> 
    </tr>
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" id="11" value="stud_cncl_inch" id="ts" /></td>
    <td><label>Student Council Incharge</label></td>
    <!--sci=Student Council Incharge--> 
    </tr>
    <tr>
    <td align="right" style="padding-top: 15px;"><label>Any Other Designation [separated by a comma(,)]</label></td>
    <td align="left"><input style="width:65%" type="text" name="other_designation" id="other" /></td>
        </tr>
  </table>
     <table id="desg_nonteaching" style="display: none;">
 <caption><h2>Designation</h2></caption>
   <tr>
   <td  align="right"><input type="checkbox" name="designation[]" value="lab_assistant" id="12" /></td>
   <td><label>Lab Assistant</label></td>
    </tr>
    
    <tr>
    <td align="right"><input type="checkbox" name="designation[]" value="lab_attendent" id="13" />
    </td>
    <td><label>Lab Attendent</label></td>
    </tr>
</table>
<br><br>
<div align="center">
<input type="submit" name="SUB" value="SUBMIT" style="width: 230px;margin-top: 15px;margin-bottom: 8px; height:40px;" >
</div>
</form>
</body>
<script type="text/javascript">
    var faculty = document.getElementById('faculty');
        if (faculty.value == "nonteaching") {
            vis2(faculty);
        }
    function myFunc(){
        var respo = <?php echo json_encode($designation); ?>; 
        var resp = $('input[name^=designation]').map(function() {
            return this.value;; 
        }).get();
        var i=0;
        var j=0;
        while(i<11){
            j=0;
            while(j<respo.length){
            if(resp[i] == respo[j]){
                var x = document.getElementById(i+1);
                x.checked = true;
            }
            j++;
            }
            i++;
        }
    }
        function vis2(field){
            var t2=document.getElementById("desg_table");
            var t3=document.getElementById("desg_nonteaching");
            if(field.value == "nonteaching"){
                t2.style.cssText='display:none';    
                t3.style.cssText='display:visible';
                var respo = <?php echo json_encode($designation); ?>; 
                var resp = $('input[name^=designation]').map(function() {
                    return this.value;; 
                }).get();
                 var i=11;
                 var j=0;
                while(i<13){
                    j=0;
                    while(j<=respo.length){
                        if(resp[i] == respo[j]){
                            var x = document.getElementById(i+1);
                            x.checked = true;
                        }
                        j++;
                    }
                i++;
                }
            }
            else{
                t2.style.cssText='display:visible';
                t3.style.cssText='display:none';
            }
        }
</script>
</html>
    