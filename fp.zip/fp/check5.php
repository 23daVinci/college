<?php
include('account.php');
?>
<?php

//session_start();
if(isset($_SESSION['eid']))
{
$empid=$_SESSION['eid'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "SELECT * from paper_publication where emp_id='$empid'";
$result = $conn->query($sql);
//$p=$result['project_title'];
$count = 0;
$Sr_No =[];
$author_name=[];
$paper_title=[];
$journal_name=[];
$year_publication2=[];
$link=[];
$s=0;
$sql2= "SELECT * from book_publication where emp_id='$empid'";
$result2 = $conn->query($sql2);
$count2=0;
$Sr_No2 =[];
$book_name=[];
$coauthor_name=[];
$publisher_name=[];
$year_publication=[];
 if ($result->num_rows > 0 || $result2->num_rows > 0) {

 while($row = $result->fetch_assoc()) {
 	$Sr_No[$count]=$row['Sr_no'];
 	$author_name[$count]=$row['author_name'];
$paper_title[$count]=$row['paper_title'];
$journal_name[$count]=$row['journal_name'];
$year_publication2[$count]=$row['year_publication'];
$link[$count]=$row['link'];
 	$count++;
 }
 while($row2 = $result2->fetch_assoc()) {
 	$Sr_No2[$count2]=$row2['Sr_no'];
 	$book_name[$count2]=$row2['book_name'];
$coauthor_name[$count2]=$row2['coauthor_name'];
$publisher_name[$count2]=$row2['publisher_name'];
$year_publication[$count2]=$row2['year_publication'];
 	$count2++;
 }
}
else
{
	header("Location:stage5.php");
}
}
else
{
	$code = 403;
	header("Location: alert.php?code=$code");
}


?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<title>Paper & Book Publication Details</title>
<style type="text/css">
	body{
		color:black !important;
	}
</style>
<script language='javascript'>
  var id=0;                                                          //id for table1
  var rid=999;                                                       //id for table2
  // function to validate table1
  function check(field){
	  //id value for element
    var i1 = Number(field.id)+1;           
	var i2 = i1+1;                          
	var i3 = i1+2;
	var i4 = i1+3;
	var i5 = i1+4;
	var i6 = i1+5;
	var i7 = i1+6;
	//retrieving element by ids
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	var s3=document.getElementById(i3);
	var s4=document.getElementById(i4);
	var s5=document.getElementById(i5);
	var s6=document.getElementById(i6);
	var s7=document.getElementById(i7);
	document.getElementById(i7).style.display = 'block';
	//disabling fields if value of paper title is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s3.value = "";	
	s4.value = "";
	s5.value = "";
	s6.value = "";
	s7.value = "";
	//s1.style.cssText = 'display:visible;';   //making select element visible
	s1.disabled = true;
	//s2.style.cssText = 'display:none;';      //changing visibility of input element to none 
	s2.disabled = true;
  	s3.disabled = true;
	s4.disabled = true;
	s5.disabled = true;
	s6.disabled = true;
    return 0;	
	}
	//enabling fields if value of paper title is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	s4.disabled = false;
	s5.disabled = false;
	s6.disabled = false;
	s7.disabled = false;
    return 0;		
	}
  }
  //funtion to validate table 1
  function check1(field){
	  // id for element
    var i1 = Number(field.id)+1;
	var i2 = i1+1;
	var i3 = i1+2;
	var i4 = i1+3;
	var i5 = i5 +4;
	// retrieving element by ids
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	var s3=document.getElementById(i3);
	var s4=document.getElementById(i4);
	var s5=document.getElementById(i5);
	//disabling fields if value of name of book is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s3.value = "";	
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	return 0;	
	}
	//enabling fields if value of name of book is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	return 0;		
	}
  }
  //function to add rows in table 1
  function addrow(tableID,i) {
          
			var table = document.getElementById(tableID);   
			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell0 = row.insertCell(0);                              //checkbox
			var element0 = document.createElement('input');
			element0.type = 'checkbox';
			element0.name = 'paper_publication_'+rowCount+'[]';
			element0.id =id+1;
			cell0.style.cssText = 'width : 100%';
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)                                 //label for numbering  
			var element1 = document.createElement('label');
			element1.name = 'paper_publication_'+rowCount+'[]';
			element1.id = id+2;
			cell1.innerHTML = rowCount;
			cell1.style.cssText = 'width : 100%; text-align:center';
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);                              //text field for author name
			var element2 = document.createElement('input');
			element2.type = 'text';
			element2.id=id+3;
			element2.name= 'paper_publication_'+rowCount+'[]';
			element2.placeholder='Aurthor-Name';
			element2.style.cssText='width:100%';
			var users = <?php echo json_encode($author_name); ?>;
			if(rowCount<=users.length){
				element2.value = users[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);                              //text field for paper title
			var element3 = document.createElement('input');
			element3.type = 'text';
			element3.id=id+4;
			element3.name= 'paper_publication_'+rowCount+'[]';
			element3.placeholder='Paper Title';
			element3.style.cssText='width:100%';
			//element3.setAttribute("onchange",'javascript:check(this)');
			var users = <?php echo json_encode($paper_title); ?>;
			if(rowCount<=users.length){
				element3.value = users[i];
			}
			else{
				element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			cell3.appendChild(element3);
			
			
			
			var cell4 = row.insertCell(4);                              //text field for name of journal
			var element4 = document.createElement('input');
			element4.type = 'text';
			element4.id=id+5;
			element4.name= 'paper_publication_'+rowCount+'[]';
			element4.placeholder='Name of Journal with volume no., issue date,page no.';
			element4.style.cssText='width:100%';
			//element4.setAttribute("onchange",'javascript:check(this)');
			var users = <?php echo json_encode($journal_name); ?>;
						//console.log(rowCount+"hi this"+users.length);
			if(rowCount<=users.length){
				element4.value = users[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);
			
			var cell5 = row.insertCell(5);          
			var element5 = document.createElement('input');               //year
			element5.type = 'text';
			element5.id=id+6;
			element5.name= 'paper_publication_'+rowCount+'[]';
			element5.style.cssText='width:100%';
			element5.placeholder='year ';
			var users2 = <?php echo json_encode($year_publication2); ?>;
			//console.log(rowCount+"hi"+users2.length);
			if(rowCount<=users2.length){
				element5.value = users2[i];
			}
			else{
				element5.value = "";
				element5.required=true;
				element5.disabled=true;
			}
			cell5.appendChild(element5);
			
			
			var cell6 = row.insertCell(6);
			var element6 = document.createElement('input');               //field for url
			element6.type = 'url';
			element6.id=id+7;
			element6.name= 'paper_publication_'+rowCount+'[]';
			element6.placeholder='http://example';
			element6.style.cssText='width:100%';
			var users = <?php echo json_encode($link); ?>;
			if(rowCount<=users.length){
				element6.value = users[i];
			}
			else{
				element6.value = "";
				element6.required=true;
				element6.disabled=true;
			}
			cell6.appendChild(element6);

			//var cell7 =row.insertCell(7)                                 //label for numbering  
			var element7 = document.createElement("input");
			element7.type = 'hidden';
			element7.name = 'paper_publication_'+rowCount+'[]';
			element7.id = id+8;
			var users = <?php echo json_encode($Sr_No); ?>;
			if(rowCount<=users.length){
				element7.setAttribute("value", users[i]);
			}
			else{
				element7.setAttribute("value", "a");
			}
			cell6.appendChild(element7);
			

        id=id+8;   
		}
	//function to add rows in table2 	
	function addrow1(tableID,i) {
          
			var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);
			console.log(rowCount);

			var cell0 = row.insertCell(0); 
			var element0 = document.createElement('input');                //checkbox
			element0.type = 'checkbox';
			element0.name = 'book_publication_'+rowCount+'[]';
			cell0.style.cssText = 'width : 100%';
			element0.id =rid+1;
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)
			var element1 = document.createElement('label');                 // label for numbering
			cell1.style.cssText = 'width : 100% ; text-align:center';
			element1.id = rid+2;
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);
			var element2 = document.createElement('input');                 //text field for name       
			element2.type = 'text';
			element2.id=rid+3;
			element2.name= 'book_publication_'+rowCount+'[]';
			element2.placeholder='Name';
			element2.style.cssText='width:100%';
			var users = <?php echo json_encode($book_name); ?>;
			//console.log(i);
			if(rowCount<=users.length){
				element2.value = users[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check1(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);
			var element3 = document.createElement('input');                  //text field for aurthor
			element3.id=rid+4;
			element3.name= 'book_publication_'+rowCount+'[]';
			element3.placeholder='Aurthor-Name';
			element3.style.cssText='width:100%';
			var users2 = <?php echo json_encode($coauthor_name); ?>;
			 //var el = document.getElementById(element1.id);
  			//console.log(rowCount);
			if(rowCount<=users2.length){
				element3.value = users2[i];
			}
			else{
				element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			cell3.appendChild(element3);
			
			var cell4 = row.insertCell(4);
			var element4 = document.createElement('input');                 //text field for publisher  
			element4.type = 'text';
			element4.id=rid+5;
			element4.name= 'book_publication_'+rowCount+'[]';
			element4.placeholder='Publisher-Name';
			element4.style.cssText='width:100%';
			var users3 = <?php echo json_encode($publisher_name); ?>;
			if(rowCount<=users3.length){
				element4.value = users3[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);
			
			var cell5 = row.insertCell(5);
			var element5 = document.createElement('input');                 //text field for year
			element5.type = 'year';
			element5.id=rid+6;
			element5.name= 'book_publication_'+rowCount+'[]';
			element5.placeholder='Year';
			element5.style.cssText='width:100%';
			var users4 = <?php echo json_encode($year_publication); ?>;
			//console.log(i);
			if(rowCount<=users4.length){
				element5.value = users4[i];
			}
			else{
				element5.value = "";
				element5.required=true;
				element5.disabled=true;
			}
			cell5.appendChild(element5);

			var element6 = document.createElement("input");
			element6.type = 'hidden';
			element6.name = 'book_publication_'+rowCount+'[]';
			element6.id = id+7;
			var users = <?php echo json_encode($Sr_No2); ?>;
			// console.log("423"+users);
			if(rowCount<=users.length){
				element6.setAttribute("value", users[i]);
			}
			else{
				element6.setAttribute("value", "a");
			}
			cell5.appendChild(element6);
			
			
		rid=rid+7;
		}	
		//function to delete row when checkbox is checked 
		function delrow(tableID,j) {
			try {
			var table = document.getElementById(tableID);//retrieving table from id
			var rowCount = table.rows.length;//no rows in table
			var rowc = rowCount;//for comparison
			var count = 0;//counter to check
			// alert(rowc);
			var c = <?php echo json_encode($author_name); ?>;
			var sr1 = <?php echo json_encode($Sr_No); ?>;
			var c2 = <?php echo json_encode($book_name); ?>;
			var sr2 = <?php echo json_encode($Sr_No2); ?>;
			// alert(tableID);
			for(var i=1; i<rowCount; i++) {
				var row = table.rows[i];
				var chkbox = row.cells[0].childNodes[0];
				//condition to delete row if checked
				if(null != chkbox && true == chkbox.checked) {
					table.deleteRow(i);
					rowCount--;
					i--;
					if(tableID=='table1'){
						if((rowc-1)<=c.length){
							window.location.href = "tast.php?sr=" + (sr1[i])+"&tableID="+"paper_publication";
						}
					} 
					if(tableID=='table2'){
						if((rowc-1)<=c2.length){
							window.location.href = "tast.php?sr=" + (sr2[i])+"&tableID="+"book_publication";
						}
					} 
					}
				else{
					//increment counter if checkbox not checked
					count+=1;
				}
			}
			//if counter is equal to no. of rows-1 then display msg
			if(count == rowc-1){
				alert("Select row to delete");
			}
			//else rearrange the numbering in table
			else{
			rearrange(tableID);
			}
			}catch(e) {
				alert(e);
			}
		}
		//function to rearrange numbering in table if row is deleted
		function rearrange(tableID) {
			alert("Selected row has been deleted");
			var table = document.getElementById(tableID);
			for (var i = 1; i < table.rows.length; i++) {
				var row = table.rows[i];
				row.cells[1].innerHTML=i;
			}
			reasign(tableID);
		}
		
		function reasign(tableID){
			var count;
			if(tableID == "table1")
				count=0;
			else
				count=999;
			var table = document.getElementById(tableID);
			for (var i = 1; i < table.rows.length; i++) {
				var row = table.rows[i];
				for (var j = 0; j < row.cells.length; j++) {
					count++;
					row.cells[j].childNodes[0].id=count;
					if(j == 3 && tableID== "table1"){
						count++;
						row.cells[j].childNodes[1].id=count;
					}
				}
			}
		}
		//function change visibility of select element& input element when value is others
		function vis(field){
			if(field.value == "Others"){
			 var a=Number(field.id);
			 var b=a+1;
			 var e1=document.getElementById(a);
			 e1.style.cssText='display:none;';
		     var e2=document.getElementById(b);
			 e2.style.cssText='display:visible;';
			 e2.disabled=false;
		    }
		}
		
</script>

<link href="ab.css" rel="stylesheet">
</head>
<!-- <div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
 --><div class="main_body" style="margin-top: 50px">  
<div id="upleft"> 
<div>
</br>
	<br>
</div>
</div>
<form id='form5' action='edit5.php' class='form5' onload="ass();" method="POST" > 
<h2 style="text-align: center">Paper Publication/Presentation</h2>
<table align='center' border='1' id='table1'  style="table-layout: fixed; width:98%" >
<tr>
 <th style="width: 6%"></th>
 <th style="width: 8%">Sr.No.</th>
 <th>Author's Name</th>
 <th>Paper Title</th>
 <th>Name of Journal with volumn No., Isuue No. , Page No./Conference</th>
 <th>Year of Publication</th>
  <th>Link</th>
 
</tr>
</table>
<p class="inline" align="center">
<input id='b1' style='height:25px;width:100px' type='button' value="Add" onclick='addrow("table1",i+1)' />
<input id='b3' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table1",j)' />
<br /><br />
</p>
<h2 style="text-align: center">Book Publication Details</h2>
<table align='center' border='1' id='table2'  style="table-layout: fixed; width:98%" >
<tr>
<th style="width: 6%"></th>
 <th style="width: 8%">Sr.No.</th>
 <th>Name of the Book</th>
 <th>Authors Name</th>
 <th>Publisher Name</th>
 <th style="width: 12%">Year Of Publication</th>
</tr>
</table>
<p class="inline" align='center' >
<input id='b2' style='height:25px;width:100px' type='button' value="Add" onclick='addrow1("table2",j+1)' />
<input id='b4' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2",j)' />
<br/><br/>
<input type="submit" name="submit" value="SUBMIT" style="width: 230px;margin-top: 15px;margin-bottom: 8px; height:40px;">
</p>
</form>
<script>
	var i=0;
	var users4 = <?php echo json_encode($year_publication); ?>;
	var users5 = <?php echo json_encode($author_name); ?>;
	console.log(users5.length);
	if (users5.length>0) {
		for(var i=0;i<users5.length;i++){
		addrow("table1",i);
		}
	}
	else{
		//for(var i=0;i<users5.length;i++){
		addrow("table1",0);
		//}
	}
	if (users4.length>0) {
		for(var j=0;j<users4.length;j++){
		addrow1("table2",j);
		}
	}
	else{
		//for(var j=0;j<3;j++){
			addrow1("table2",0);
		//}
	}
	
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
</div>
</html>