<?php

echo phpversion();

?>