<?php
include('account.php');
?>

<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
#records {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 63%;

}

#records td, #records th {
    border: 1px solid #A9A9A9;
    padding: 8px;
}

#records th:nth-child(odd) {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #DCDCDC;
    color: black;
    width: 30%;
}
#records th:nth-child(even) {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: white;
    color: black;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}


hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 

body {
    font-family: "Lato", sans-serif;
    color:black;
}
	
</style>
</head>
<body>
<!-- <div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
 -->   <br>
   <div>
   	<h2 align="center">
  EMPLOYMENT DETAILS</h2>
   </div>



<?php
//session_start();
$empid=$_SESSION['eid'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "SELECT * from staff_emp_details where emp_id='$empid'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        //echo "Lastname: " . $row["last_name"]. " <br> Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";

        echo "<table id='records' align='center'>

<tr>

<th>Employee ID</th>

<td>". $row['emp_id'] ."</td>

</tr>

<tr>

<th>Faculty type</th>

<td>". $row['faculty_type'] ."</td>

</tr>


<tr>

<th>Appointment type</th>

<td>". $row['appointment_type'] ."</td>

</tr>

<tr>

<th>Library card number</th>

<td>". $row['Library_card_no'] ."</td>

</tr>

<tr>

<th>Department name</th>

<td>". $row['Dept_name'] ."</td>

</tr>


<tr>

<th>Highest qualification</th>

<td>". $row['highest_qualif'] ."</td>

</tr>


</table>";
} }
else {
    echo "<br><br> <b>Employment details not yet filled</b>";
}
$conn->close();
?>

</body>
</html>