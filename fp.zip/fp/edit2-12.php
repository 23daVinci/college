<?php
include('account.php');
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
	.navbar {
    overflow: hidden;
    background-color: #DCDCDC;
    font-family: Arial;
}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: black;
    padding: 14px 16px;
    background-color: inherit;
    font: inherit;
    margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: 	#C0C0C0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 130px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
</head>
<body style="color: black;">
<div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
   <div class="navbar">
  <div class="dropdown">
    <button class="dropbtn">Personal Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view1.php">View</a>
      <a href="check.php">Edit</a>
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Staff Employment Details-1 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view2.php">View</a>
      <a href="check2-1.php">Edit</a>
      
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Staff Employment Details-2 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view2-2.php">View</a>
      <a href="check2-2.php">Edit</a>
      
    </div>
  </div> 

  <div class="dropdown">
    <button class="dropbtn">Responsibilities Handled
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view3.php">View</a>
      <a href="edit3.php">Edit</a>
      
    </div>
  </div>
  <div class="dropdown">
    <button class="dropbtn">R&D Destails 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view4.php">View</a>
      <a href="check4.php">Edit</a>
      
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Paper & Book Publication Details
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view5.php">View</a>
      <a href="check5.php">Edit</a>
      
    </div>
  </div>  

</div>
<?php
session_start();
//print_r($_SESSION);

print_r($_SESSION['eid']);

$empid=$_SESSION['eid'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$faculty_type = $_POST['faculty_type'];
$appointment_type = $_POST['appointment_type'];
$Dept_name = $_POST['Dept_name'];
$college_emp_id = $_POST['college_emp_id'];
$Library_card_no = $_POST['Library_card_no'];
$highest_qualif= $_POST['highest_qualif'];


$sql2 = "UPDATE staff_emp_details SET faculty_type = '$faculty_type',appointment_type = '$appointment_type',Dept_name = '$Dept_name',college_emp_id = '$college_emp_id',Library_card_no = '$Library_card_no', highest_qualif = '$highest_qualif' WHERE emp_id='$empid'";

if ($conn->query($sql2) === TRUE) {
    echo "<br>Record updated successfully";
} else {
    echo "Error: " . $sql2 . "<br>" . $conn->error;
}

$conn->close();
?>
</body>
</html>