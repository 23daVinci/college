<?php
include('account.php');
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
	.navbar {
    overflow: hidden;
    background-color: #DCDCDC;
    font-family: Arial;
}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: black;
    padding: 14px 16px;
    background-color: inherit;
    font: inherit;
    margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: 	#C0C0C0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 130px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
</head>
<body style="color: black;">
<div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
   <div class="navbar">
  <div class="dropdown">
    <button class="dropbtn">Personal Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view1.php">View</a>
      <a href="check.php">Edit</a>
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Staff Employment Details-1 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view2.php">View</a>
      <a href="check2-1.php">Edit</a>
      
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Staff Employment Details-2 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view2-2.php">View</a>
      <a href="check2-2.php">Edit</a>
      
    </div>
  </div> 

  <div class="dropdown">
    <button class="dropbtn">Responsibilities Handled
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view3.php">View</a>
      <a href="edit3.php">Edit</a>
      
    </div>
  </div>
  <div class="dropdown">
    <button class="dropbtn">R&D Destails 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view4.php">View</a>
      <a href="check4.php">Edit</a>
      
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Paper & Book Publication Details
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view5.php">View</a>
      <a href="check5.php">Edit</a>
      
    </div>
  </div>  

</div>
<?php
//session_start();
//print_r($_SESSION);

$empid=$_SESSION['eid'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$last_name = $_POST['last_name'];
$middle_name = $_POST['middle_name'];
$first_name = $_POST['first_name'];
$spouse_name = $_POST['spouse_name'];
$dob = $_POST['dob'];
$Gender = $_POST['Gender'];
$marital_status = $_POST['marital_status'];
$mobile_no = $_POST['mobile_no'];
$residential_no = $_POST['residential_no'];
$email = $_POST['email'];
$alt_email = $_POST['alt_email'];
$pan_no = $_POST['pan_no'];
$pf_no = $_POST['pf_no'];
$aadhar = $_POST['aadhar'];
$permanent_address = $_POST['permanent_address'];
$current_address = $_POST['current_address'];
$mothers_name = $_POST['mothers_name'];
$fathers_name = $_POST['fathers_name'];
$religion = $_POST['religion'];
$category = $_POST['category'];
$caste = $_POST['caste'];
$nationality = $_POST['nationality'];
$passport_no = $_POST['passport_no'];
$form_16 = $_POST['form_16'];
$bank_name = $_POST['bank_name'];
$acc_no = $_POST['acc_no'];
$IFSC_code = $_POST['IFSC_code'];
$branch = $_POST['branch'];
$bank_acc_holder_name = $_POST['bank_acc_holder_name'];





$sql2 = "UPDATE faculty_personal_details SET last_name = '$last_name',middle_name = '$middle_name',first_name = '$first_name',spouse_name = '$spouse_name',dob = '$dob', Gender = '$Gender', marital_status = '$marital_status', mobile_no = '$mobile_no',residential_no = '$residential_no', email = '$email', alt_email = '$alt_email',pan_no = '$pan_no', pf_no = '$pf_no', aadhar = '$aadhar',permanent_address = '$permanent_address', current_address = '$current_address', mothers_name = '$mothers_name', fathers_name = '$fathers_name', religion = '$religion', category = '$category', caste = '$caste',nationality = '$nationality', passport_no = '$passport_no',form_16 = '$form_16'
 WHERE emp_id='$empid'";


if ($conn->query($sql2) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error: " . $sql2 . "<br>" . $conn->error;
}

$sql1 = "UPDATE bank_account_details SET bank_name = '$bank_name', acc_no = '$acc_no',IFSC_code = '$IFSC_code',branch = '$branch',bank_acc_holder_name = '$bank_acc_holder_name' WHERE emp_id='$empid'";


if ($conn->query($sql1) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error: " . $sql1 . "<br>" . $conn->error;
}


$conn->close();
?>
</body>
</html>