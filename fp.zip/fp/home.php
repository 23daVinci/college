<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #DCDCDC;
}

li {
    float: left;
}

li a {
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color:   #C0C0C0;
}
li {
    float: left;
    border-right:1px solid white;
}


</style>

</head>
<div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
<ul>
  <li><a class="active" href="home.php">Home</a></li>
  <li><a href="login.php">Log In</a></li>
  <li><a href="stage1.php">Sign Up</a></li>
  
</ul>

<img src="college1.jpg" alt="college"  style="width: 100%; height: 50%;" >

</html>

