<?php
include('account.php');
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
.navbar {
    overflow: hidden;
    background-color: #DCDCDC;
    font-family: Arial;
}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: black;
    padding: 14px 16px;
    background-color: inherit;
    font: inherit;
    margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color:   #C0C0C0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 130px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}

#records {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 63%;

}

#records td, #records th {
    border: 1px solid #A9A9A9;
    padding: 8px;
}

#records th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #DCDCDC;
    color: black;
    width: 30%;
}
#records td {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: white;
    color: black;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}


hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 

body {
    font-family: "Lato", sans-serif;
    color:black;
}
	
</style>
<script type='text/javascript'>

   function check_category(val)
   {
      if(val==='others')
            document.getElementById('other_category').removeAttribute('disabled');
         else
            document.getElementById('other_category').setAttribute('disabled','true'); 
   }

   function check_religion(val)
   {
      if(val==='others')
            document.getElementById('other_religion').removeAttribute('disabled');
         else
            document.getElementById('other_religion').setAttribute('disabled','true'); 
   }
     
   function check_nationality(val)
   {
      if(val==='others')
            document.getElementById('other_nationality').removeAttribute('disabled');
      else
            document.getElementById('other_nationality').setAttribute('disabled','true');

   }
</script>
</head>
<body align='center'>
<!-- <div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
 -->   <br>
   <div>
   	<h2 align="center">
   	PERSONAL INFORMATION</h2>
   </div>

<?php
//session_start();
//print_r($_SESSION);


$empid=$_SESSION['eid'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "SELECT * from faculty_personal_details where emp_id='$empid'";
$result = $conn->query($sql);

$sql1= "SELECT * from bank_account_details where emp_id='$empid'";
$result1 = $conn->query($sql1);

if ($result->num_rows > 0 && $result1->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        //echo "Lastname: " . $row["last_name"]. " <br> Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";

        echo "
<form action='edit1.php' method='post' align='center'>
        <table id='records' align='center'>

<tr>

<th>Last name</th>

<td><input type='text' name='last_name' required value=".$row['last_name']."></td>

</tr>


<tr>

<th>Middle name</th>

<td><input type='text' name='middle_name' required value=".$row['middle_name']." ></td>

</tr>

<tr>

<th>First name</th>

<td><input type='text' name='first_name' required value=".$row['first_name']."></td>

</tr>

<tr>

<th>Mother's name</th>

<td><input type='text' name='mothers_name' required value=".$row['mothers_name']."></td>

</tr>

<tr>

<th>Father's name</th>

<td><input type='text' name='fathers_name' required value=".$row['fathers_name']."></td>

</tr>

<tr>

<th>Gender</th>

<td><select name='Gender' required>
<option value=".$row['Gender']." selected='selected'>".$row['Gender']."</option>
<option value='female'>Female</option>
  <option value='male'>Male</option>
  </select>
  </td>

</tr>

<tr>

<th>Marital status</th>

<td><select name='marital_status' required >
<option value=".$row['marital_status']." selected='selected'>".$row['marital_status']."</option>
<option value='Unmarried'>Unmarried</option>
  <option value='Married'>Married</option>
  </select></td>

</tr>

<th>Spouse name</th>

<td><input type='text' name='spouse_name'  required value=".$row['spouse_name']."></td>

</tr>


<tr>

<th>Date of Birth</th>

<td><input type='date' name='dob'  required value=".$row['dob']."></td>

</tr>

<tr>

<th>Mobile number</th>

<td><input type='tel' name='mobile_no' minlength='10' maxlength='10' required value=".$row['mobile_no']." ></td>

</tr>

<tr>

<th>Residential number</th>

<td><input type='text' name='residential_no' required value=".$row['residential_no']."></td>

</tr>

<tr>

<th>Email id</th>

<td><input type='email' name='email' required value=".$row['email']." ></td>

</tr>

<tr>

<th>Alternate email id</th>

<td><input type='email' name='alt_email' required value=".$row['alt_email']."></th>

</tr>

<tr>

<th>Current Address</th>

<td><input type='text' name='current_address' required value=".$row['current_address']."></td>

</tr>

<tr>

<th>Permanent Address</th>

<td><input type='text' name='permanent_address' required value=".$row['permanent_address']."></td>

</tr>

<tr>

<th>PAN number</th>

<td><input type='text' name='pan_no'  required minlength='10' maxlength='10' value=".$row['pan_no']." required minlength='10' maxlength='10'></td>

</tr>

<tr>

<th>PF Number</th>

<td><input type='text' name='pf_no' required value=".$row['pf_no'].">  </td>

</tr>

<tr>
                        <th>Aadhar Card Number :</th>
                        <td>
                           <input type='text' name='aadhar' id='adhar' required='true' minlength='12' maxlength='12' value=".$row['pf_no'].">
                        </td>
                     </tr>


<th >Passport Number :</th>
                        <td>
                           <input type='text' name='passport_no' id='passport_no' minlength='8' maxlength='9' value=".$row['pf_no'].">
                        </td>
                     </tr>
                     <tr>
                        <th>Nationality :</th>
                        <td>
                           <select name='nationality' id='nationality' onchange='check_nationality(this.value)' required>
                              <option value=".$row['nationality']." selected='selected'>".$row['nationality']."</option>
                              <option value='indian'>Indian</option>
                              <option value='others'>Others</option>
                           </select>
                           <input type='text' id='other_nationality' name='other_nationality'  disabled='true' required>
                        </td>
                     </tr>
                     <tr>
                        <th>Religion :</th>
                        <td>
                           <select name='religion' id='religion' onchange='check_religion(this.value)' required>
                              <option value=".$row['religion']." selected='selected'>".$row['religion']."</option>
                              <option value='Hinduism'>Hinduism</option>
                              <option value='Islam'>Islam</option>
                              <option value='Christianity'>Christianity</option>
                              <option value='Buddhism'>Sikhism </option>
                              <option value='Jainism'>Bhuddhism</option>
                              <option value='Parsi'>Parsi</option>
                              <option value='others'>Others</option>
                           </select>
                           <input type='text' name='other_religion' id='other_religion'  disabled='true' required>
                        </td>
                     </tr>
                     <tr>
                        <th>Category :</th>
                        <td>
                           <select required name='category' id='category' onchange='check_category(this.value)'> 
                              <option value=".$row['category']." selected='selected'>".$row['category']."</option>
                              <option value='open'>Open</option>
                              <option value='obc'>OBC</option>
                              <option value='sbc'>SBC</option>
                              <option value='sc'>SC</option>
                              <option value='nt'>NT</option>
                              <option value='ntdt'>NT</option>
                              <option value='vj'>VJ</option>
                              <option value='others'>Others</option>
                           </select> 
                           <input type='text' name='other_category' id='other_category' disabled='true' required='true'>
                        </td>
                     </tr>
                     <tr>
                        <th>Caste :</th>
                        <td>
                           <input type='text' name='caste' id='caste' required value=".$row['caste'].">
                        </td>
                     </tr>

                     <tr>
                        <th>Form 16 </th>
                        <td>
                           <select name='form_16' id='form16' required>
                              <option value=".$row['form_16']." selected='selected'>".$row['form_16']."</option>
                              <option value='AnS'>Applicable and Submitted</option>
                              <option value='AnNS'>Applicable and Not Submitted</option>
                              <option value='nA'> Not Applicable</option>     
                           </select>
                        </td>
                     </tr>";
}/* }
else {
    echo "0 results";
}

if ($result1->num_rows > 0) {
    // output data of each row*/
    while($row1 = $result1->fetch_assoc()) {
        echo "

                    <tr> 
                        <th>Bank Name :</th>
                        <td>
                           <input type='text' name='bank_name' id='bank_name' required value=".$row1['bank_name'].">
                        </td>
                     </tr>
                     <tr>
                        <th>Account Number </th>
                        <td>
                           <input type='text' name='acc_no' id='account_no' maxlength='17' required='true' value=".$row1['acc_no'].">
                        </td>
                     </tr>
                     <tr>
                        <th>Account Holder's Name </th>
                        <td>
                           <input type='text' name='bank_acc_holder_name' id='acc_holder_name' required value=".$row1['bank_acc_holder_name'].">
                        </td>
                     </tr>
                     <tr>
                        <th>Enter IFS Code </th>
                        <td>
                           <input type='text' name='IFSC_code' id='ifsc' maxlength='11' minlength='11' required='true' value=".$row1['IFSC_code'].">
                        </td>
                     </tr>
                     <tr>
                        <th>Branch Name </th>
                        <td>
                           <input type='text' name='branch' id='bank_branch' required value=".$row1['branch'].">
                        </td>
                     </tr>
                     </table>
                     <br>
                     <center>
<input type='submit' name='submit' value='Submit'>
<br>
</center>
</form>";
} }
else {
    echo "0 results";
}


$conn->close();
?>
</body>
</html>


