<?php
include('account.php');
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
<style type="text/css">
#records {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#records td, # th {
    border: 1px solid #ddd;
    padding: 8px;
}

#records tr:nth-child(even){background-color: #f2f2f2;}

#records tr:hover {background-color: #ddd;}

#records th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #DCDCDC;
    color: black;
}


#records td {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: white;
    color: black;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}


hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 

body {
    font-family: "Lato", sans-serif;
    color:black;
}
  
</style>
</head>
<body onload="myFunc();">
<br>
   <div>
    <h2 align="center">
  RESPONSIBILITIES HANDLED</h2>
   </div>


<?php
//session_start();
$empid=$_SESSION['eid'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "SELECT * from other_responsibility where emp_id='$empid'";
$result = $conn->query($sql);

$count1 = 0;
$Sr_No1 =[];
$responsibility = [];

if ($result->num_rows > 0 ) {
while($row1 = $result->fetch_assoc()) {
    $Sr_No1[$count1]=$row1['Sr_no'];
    $responsibility[$count1]=$row1['responsibility'];
    $count1++;
 }
}
    if(isset($_POST['SUB']) && isset($_POST['responsibilities']))
    {   
        $emp_id = $_SESSION['eid'];
        $responsibilities = $_POST['responsibilities'];
        $q = "DELETE FROM other_responsibility WHERE emp_id='$emp_id'";
        $r = mysqli_query($conn,$q);

        if(!empty($_POST['other_resp']))
        {
            $other_resp = explode(',',$_POST['other_resp']);
            $responsibilities = array_merge($responsibilities,$other_resp);
            //print_r($responsibilities);
        }

        $conn = mysqli_connect("localhost" , "root" ,"");

        if(!$conn)
        {
            $code = 500;
            header("Location: alert.php?code=$code");
        }

        mysqli_select_db($conn,"college");
        //insert into other_responsibility
        foreach ($responsibilities as $key => $value) 
        {
            $sql1 = "insert into other_responsibility (emp_id,responsibility) values('$emp_id','$value') ";

            $insert_result1 = mysqli_query($conn,$sql1);

            if($insert_result1)
            {
                //print("Submission Done");
            }
            else
            {
                $code = 500;
                header("Location: alert.php?code=$code");
            }
        }
        $sql= "SELECT * from other_responsibility where emp_id='$empid'";
        $result = $conn->query($sql);

        $count1 = 0;
        $Sr_No1 =[];
        $responsibility = [];

        if ($result->num_rows > 0 ) {
            while($row1 = $result->fetch_assoc()) {
                $Sr_No1[$count1]=$row1['Sr_no'];
                $responsibility[$count1]=$row1['responsibility'];
                $count1++;
            }
        }
    }
    else if(isset($_POST['SUB']) && !isset($_POST['responsibilities'])){
        $emp_id = $_SESSION['eid'];
        $q = "DELETE FROM other_responsibility WHERE emp_id='$emp_id'";
        $r = mysqli_query($conn,$q);
         $sql= "SELECT * from other_responsibility where emp_id='$empid'";
        $result = $conn->query($sql);

        $count1 = 0;
        $Sr_No1 =[];
        $responsibility = [];

        if ($result->num_rows > 0 ) {
            while($row1 = $result->fetch_assoc()) {
                $Sr_No1[$count1]=$row1['Sr_no'];
                $responsibility[$count1]=$row1['responsibility'];
                $count1++;
            }
        }
    }

$conn->close();
?>
<?php
if(isset($_POST['check'])){
    $name=$_POST['check'];
    //print_r($name);
    $empid=$_SESSION['eid'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
    for($i=0;$i<sizeof($name);$i++){
        $n = $name[$i];
        //echo $n;
        $sql = "DELETE FROM other_responsibility where responsibility = '$n' ";
        $result = $conn->query($sql);
        //mysql_query($sql);
    }
}
?>
<form method="POST">
 <table align='center' border='1' name="qualific_details" style="table-layout: fixed; width:99%">
 <caption><h2>Responsibilites Handled by Faculty</h2></caption>

    <tr>
        <td  align="center" style="width:5%">
            <input type="checkbox" name="responsibilities[]"  value="dept_seminar_work_inch" id="1"/>
        </td>
        <td>
            <label>Incharge of Departmental Seminar / Workshop</label>
        </td>
    <!--<td></td> -->
        <td  align="center" style="width:5%">
            <input type="checkbox" name="responsibilities[]" value="store_incharge" id="2"/>
        </td>
        <td>
            <label>Store Incharge</label>
        </td>
    </tr>
    
    <tr>
        <td align="center">
            <input type="checkbox" name="responsibilities[]" value="etamax_coordinator" id="3" />
        </td>
        <td>
            <label>Etamax Coordinator</label>
        </td>       
    <!--<td></td> -->
        <td align="center">
            <input type="checkbox" name="responsibilities[]" value="dept_lib_incharge" id="4" />
        </td>
        <td>
            <label>Department Library Incharge</label>
        </td>
        </tr>
    
        <tr>
            <td align="center">
                <input type="checkbox" name="responsibilities[]" value="faces_coordinator" id="5" />
            </td>
            <td>
                <label>Faces Coordinator</label>
            </td>
    <!--<td></td> -->
            <td align="center">
                <input type="checkbox" name="responsibilities[]" value="fe_admission" id="6" />
            </td>
            <td>
                <label>First Year Admission</label>
            </td>
        </tr>

    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="exam_conduction" id="7" /></td>
    <td><label>Exam Conduction</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="lpp_incharge" id="8" /></td>
    <td><label>LCD Projector / Printer Incharge </label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="ut_conduction" id="9" /></td>
    <td><label>UT Conduction</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="trekking" id="10" /></td>
    <td><label>Trekking</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="felic_overall_coord" id="11" /></td>
    <td><label>Felicitation Coordinator (Dept. / Overall Coordinator)</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="indust_visit" id="12" /></td>
    <td><label>Industrial Visit</label></td>
    </tr>
    <tr>
    <td  align="center"><input type="checkbox" name="responsibilities[]" value="convocation_coord" id="13" /></td>
    <td><label>Convocation Coordinator (Dept. / Overall Coorodinator)</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="accrediation_inch" id="14" /></td>
    <td><label>Accrediation(NBA) Incharge / Department Coordinator</label></td>
    </tr>

    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="icnte_member" id="15" /></td>
    <td><label>ICNTE Convener/Co-convener / Committee Member</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="rnd_dept_coord" id="16" /></td>
    <td><label>Dean R&D / Department Coordiantor</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="felic_centre_coord" id="17" /></td>
    <td><label>Felicitaion Centre Coordinator</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="dean_stud_affairs" id="18" /></td>
    <td><label>Dean Student Affairs</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="pti_inch" id="19" /></td>
    <td><label>PTI Incharge </label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="exam_cell_coord" id="20" /></td>
    <td><label>Exam Cell Coordinator</label></td>
    </tr>


    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="class_teacher" id="21" /></td>
    <td><label>Class Teacher / Co-class Teacher</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="dpt_magaz_inch" id="22" /></td>
    <td><label>Department Magzine Incharge</label></td>
    </tr>


    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="sum_win_course_inch" id="23" /></td>
    <td><label>Summer / Winter Course Incharge</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="aicte_inch" id="24" /></td>
    <td><label>AICTE Incharge</label></td>
    </tr>


    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="lic_comm_inch" id="25" /></td>
    <td><label>LIC Committee Incharge / Department Coordinator</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="proj_coord" id="26" /></td>
    <td><label>Project Coordinator</label></td>
    </tr>

    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="tt_inch" id="27" /></td>
    <td><label>Time Table Incharge</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="placement_inch" id="28" /></td>
    <td><label>Placement Incharge / Department Coordinator</label></td>
    </tr>

    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="alumina_inch" id="29" /></td>
    <td><label>Alumina Incharge</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="lab_inch" id="30" /></td>
    <td><label>Lab Incharge</label></td>
    <tr>

    <td align="center"><input type="checkbox" name="responsibilities[]" value="fe_engg_adm" id="31" /></td>
    <td><label>First Year Engineering Admission</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="dean_academ" id="32" /></td>
    <td><label>Dean Academics</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="st_cncl_inch" id="33" /></td>
    <td><label>Student Council Incharge</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="dean_pg" id="34" /></td>
    <td><label>Dean P.G (Higher Studies)</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="cheif_cond_exam" id="35"></td>
    <td><label>Chief Conductor of Examination</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="ss_samitee" id="36" /></td>
    <td><label>Shikshan Shulk Samitee</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="sen_sup" id="37" /></td>
    <td><label>Senior Supervisor</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="univ_affil_inch" id="38" /></td>
    <td><label>University Affilitions Incharge / Departmental Coordinator</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="exam_cell_inch" id="39" /></td>
    <td><label>Exam Cell Incharge</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="me_coord" id="40" /></td>
    <td><label>M.E Coordinator</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="clg_magaz_inch" id="41" /></td>
    <td><label>College Magzine Incharge</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="phd_coord" id="42" /></td>
    <td><label>Ph.D Coordinator</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="hod" id="43" /></td>
    <td><label>HOD</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="prof_soc_inch" id="44" /></td>
    <td><label>Professional Society Incharge</label></td>
    </tr>
    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="coordinator" id="45" /></td>
    <td><label>Coordinator</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="contrlr_exam" id="46" /></td>
    <td><label>Controller of Examination</label></td>
    
    </tr>

    <tr>
    <td align="center"><input type="checkbox" name="responsibilities[]" value="d_contrlr_inch" id="47" /></td>
    <td><label>Deputy Controller of Examination</label></td>
    <!--<td></td> -->
    <td align="center"><input type="checkbox" name="responsibilities[]" value="felic_cent_coord" id="48" /></td>
    <td><label>Felicitaion Centre Coordinator</label></td>
    
    </tr>

<tr>

    <td></td>
    <td align="center">
        <label style="padding-top:8px">Any Other : </label>
        <input type="textbox" name="other_resp" id="other_resp" style="width:300px;" align='left'>
    </td>
    <td></td>
    <td></td>
    
</tr>
 </table>

    <br>
    <center>
        <input type="submit" value="SUB" name="SUB" style="width: 230px;margin-top: 15px;margin-bottom: 20%; height:40px;" >
</center>
</form>
</body>
<script type="text/javascript">
    function myFunc(){
        var respo = <?php echo json_encode($responsibility); ?>; 
        var resp = $('input[name^=responsibilities]').map(function() {
            return this.value;; 
        }).get();
        var i=0;
        var j=0;
        while(i<48){
            j=0;
            console.log(resp[i]);
            while(j<respo.length){
            if(resp[i] == respo[j]){
                var x = document.getElementById(i+1);
                x.checked = true;
                console.log("here");
            }
            j++;
            }
            i++;
        }
    }
</script>
</html>


