
<?php
include('account.php');
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
	.navbar {
    overflow: hidden;
    background-color: #DCDCDC;
    font-family: Arial;
}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: black;
    padding: 14px 16px;
    background-color: inherit;
    font: inherit;
    margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: 	#C0C0C0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 130px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
</head>
<body>

<?php

//session_start();
$emp_id = $_SESSION['eid'];
print_r($_POST);
error_reporting(E_ERROR | E_PARSE);

$non_empty = [];
$final = [];
foreach ($_POST as $key => $value) 
{
	//echo($key);
	foreach ($value as $inner_key => $inner_value) 
	{
		if(!empty($inner_value))
		{	
			array_push($non_empty,$key);
			//print($inner_value);
			//print("&nbsp;");
			array_push($final, $inner_value);

		}
	}
	//echo("<br>");
}

/*
print_r($final);
echo "<br>";
print_r($non_empty);
*/

$internal_proj = [];
$external_proj = [];


foreach ($non_empty as $key => $value) 
{
	if(strpos($value,'internal_proj_') !== false)
	{
		array_push($internal_proj,$final[$key]);
	}


	if(strpos($value,'external_proj_') !== false)
	{
		array_push($external_proj,$final[$key]);
	}

}


// echo "<br>";
// print_r($internal_proj);
// echo "<br>";
// print_r($external_proj);


$ip_itr = 8;
$ep_itr = 11;

$ip_rcount = floor(count($internal_proj)/$ip_itr);
$ep_rcount = floor(count($external_proj)/$ep_itr);

// print($ip_rcount);
// print($ep_rcount);
$conn = mysqli_connect("localhost" , "root" ,"");

	if(!$conn)
	{echo "error in connection";}
	else
	{echo " connection established";} 

	mysqli_select_db($conn,"college");

if($ip_rcount > 0)
{
	for($curr_row = 1; $curr_row <= $ip_rcount; $curr_row++)
	{	
		${"internal_proj_$curr_row"} = [];
		for($i = ($ip_itr*($curr_row-1)); $i< ($ip_itr*($curr_row)) ; $i++)
		{
			array_push(${"internal_proj_$curr_row"}, $internal_proj[$i]);
		}
	}

	for($i=1;$i<=$ip_rcount;$i++)
	{

		//print_r(${"internal_proj_$i"});
		//echo "<br>";
		$_SESSION["internal_proj_$i"] = ${"internal_proj_$i"};
		$ip["$i"] = $_SESSION["internal_proj_$i"];
	}
	
	for($i=1;$i<=$ip_rcount;$i++){
$query = "insert into internal_fundedproject(Sr_no,emp_id,Project_title,staff_name,student_name,department,year,project_cost,project_utility) values ('".$ip["$i"][7]."','$emp_id','".$ip["$i"][0]."','".$ip["$i"][1]."','".$ip["$i"][2]."','".$ip["$i"][3]."','".$ip["$i"][4]."','".$ip["$i"][5]."','".$ip["$i"][6]."') on duplicate key update Sr_no='".$ip["$i"][7]."',Project_title='".$ip["$i"][0]."',staff_name='".$ip["$i"][1]."',student_name='".$ip["$i"][2]."',department='".$ip["$i"][3]."',year='".$ip["$i"][4]."',project_cost='".$ip["$i"][5]."',project_utility='".$ip["$i"][6]."' ";
			//echo($query);
			//echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in internal_fundedproject inserted";
			}
			else
			{
				echo "error in internal_fundedproject insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
}




if($ep_rcount > 0)
{
	for($curr_row = 1; $curr_row <= $ep_rcount; $curr_row++)
	{	
		${"external_proj_$curr_row"} = [];
		for($i = ($ep_itr*($curr_row-1)); $i< ($ep_itr*($curr_row)) ; $i++)
		{
			array_push(${"external_proj_$curr_row"}, $external_proj[$i]);
		}
	}

	for($i=1;$i<=$ep_rcount;$i++)
	{
		//print_r(${"internal_proj_$i"});
		//echo "<br>";
		$_SESSION["external_proj_$i"] = ${"external_proj_$i"};
		$ep["$i"] = $_SESSION["external_proj_$i"];
	}
	
	for($i=1;$i<=$ep_rcount;$i++){
			$query = "insert into external_fundedproject(Sr_no,emp_id,Project_title,principal,co_invest,duration_from,duration_to,project_cost,amount,grant_type,funding,patents_publication) values ('".$ep["$i"][10]."','$emp_id','".$ep["$i"][0]."','".$ep["$i"][1]."','".$ep["$i"][2]."','".$ep["$i"][3]."','".$ep["$i"][4]."','".$ep["$i"][5]."','".$ep["$i"][6]."','".$ep["$i"][7]."','".$ep["$i"][8]."','".$ep["$i"][9]."') on duplicate key update Sr_no='".$ep["$i"][10]."',emp_id='$emp_id',Project_title='".$ep["$i"][0]."',principal='".$ep["$i"][1]."',co_invest='".$ep["$i"][2]."',duration_from='".$ep["$i"][3]."',duration_to='".$ep["$i"][4]."',project_cost='".$ep["$i"][5]."',amount='".$ep["$i"][6]."',grant_type='".$ep["$i"][7]."',funding='".$ep["$i"][8]."',patents_publication='".$ep["$i"][9]."' ";
			//echo($query);
			//echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in external_fundedproject inserted";
			}
			else
			{
				echo "error in external_fundedproject insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
}

//echo("<br><br>");
//print_r($_SESSION);
// header( "refresh:1; url=account.php" ); 


?>
</body>
</html>