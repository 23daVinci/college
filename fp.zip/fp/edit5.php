
<?php
include('account.php');
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
	.navbar {
    overflow: hidden;
    background-color: #DCDCDC;
    font-family: Arial;
}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: black;
    padding: 14px 16px;
    background-color: inherit;
    font: inherit;
    margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: 	#C0C0C0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 130px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
</head>
<body>
<?php

//session_start();
print_r($_SESSION['eid']);
$emp_id = $_SESSION['eid'];
print_r($_POST);
//echo "<br><br>";

error_reporting(E_ERROR | E_PARSE);

$non_empty = [];
$final = [];
foreach ($_POST as $key => $value) 
{
	//echo($key);
	foreach ($value as $inner_key => $inner_value) 
	{
		if(!empty($inner_value))
		{	
			array_push($non_empty,$key);
			//print($inner_value);
			//print("&nbsp;");
			array_push($final, $inner_value);
		}
	}
	//echo("<br>");
}


//print_r($final);
//echo "<br>";
//print_r($non_empty);


$paper_publication = [];
$book_publication = [];


foreach ($non_empty as $key => $value) 
{
	if(strpos($value,'paper_publication_') !== false)
	{
		array_push($paper_publication,$final[$key]);
	}


	if(strpos($value,'book_publication_') !== false)
	{
		array_push($book_publication,$final[$key]);
	}

}


echo "Printing";
echo "<br>";
print_r($paper_publication);
echo "<br>";
print_r($book_publication);


$pp_itr = 6;
$bp_itr = 5;

$pp_rcount = round(count($paper_publication)/$pp_itr);
$bp_rcount = count($book_publication)/$bp_itr;

//echo "<br>";
print($pp_rcount);
print($bp_rcount);

$conn = mysqli_connect("localhost" , "root" ,"");

	if(!$conn)
	{echo "error in connection";}
	else
	{echo " connection established";} 

	mysqli_select_db($conn,"college");
if($pp_rcount > 0)
{
	for($curr_row = 1; $curr_row <= $pp_rcount; $curr_row++)
	{	
		${"paper_publication_$curr_row"} = [];
		for($i = ($pp_itr*($curr_row-1)); $i< ($pp_itr*($curr_row)) ; $i++)
		{
			
			array_push(${"paper_publication_$curr_row"}, $paper_publication[$i]);
		}
	}
			//echo("<br>");

	for($i=1;$i<=$pp_rcount;$i++)
	{
		//print_r(${"paper_publication_$i"});
		echo "<br>";
		$_SESSION["paper_publication_$i"] = ${"paper_publication_$i"};
		$pp["$i"] = $_SESSION["paper_publication_$i"];
	}
	for($i=1;$i<=$pp_rcount;$i++){
			$query = "insert into paper_publication(Sr_no,emp_id,author_name,paper_title,journal_name,year_publication,link) values ('".$pp["$i"][5]."','$emp_id','".$pp["$i"][0]."','".$pp["$i"][1]."','".$pp["$i"][2]."','".$pp["$i"][3]."','".$pp["$i"][4]."') on DUPLICATE KEY update Sr_no='".$pp["$i"][5]."',author_name='".$pp["$i"][0]."',paper_title='".$pp["$i"][1]."',journal_name='".$pp["$i"][2]."',year_publication='".$pp["$i"][3]."',link='".$pp["$i"][4]."'";
			echo($query);
			//echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in paper_publication inserted";
			}
			else
			{
				echo "error in paper_publication insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
}




if($bp_rcount > 0)
{
	for($curr_row = 1; $curr_row <= $bp_rcount; $curr_row++)
	{	
		${"book_publication_$curr_row"} = [];
		for($i = ($bp_itr*($curr_row-1)); $i< ($bp_itr*($curr_row)) ; $i++)
		{
			array_push(${"book_publication_$curr_row"}, $book_publication[$i]);
		}
	}
	echo("<br>");
	for($i=1;$i<=$bp_rcount;$i++)
	{
		print_r(${"book_publication_$i"});
		//echo "<br>";
		$_SESSION["book_publication_$i"] = ${"book_publication_$i"};
		$bp["$i"] = $_SESSION["book_publication_$i"];
	}
	
	for($i=1;$i<=$bp_rcount;$i++){
			$query = "insert into book_publication(Sr_no,emp_id,book_name,coauthor_name,publisher_name,year_publication) values ('".$bp["$i"][4]."','$emp_id','".$bp["$i"][0]."','".$bp["$i"][1]."','".$bp["$i"][2]."','".$bp["$i"][3]."') on duplicate key update Sr_no='".$bp["$i"][4]."', book_name='".$bp["$i"][0]."',coauthor_name='".$bp["$i"][1]."',publisher_name='".$bp["$i"][2]."',year_publication='".$bp["$i"][3]."'";
			echo($query);
			//echo("<br>");

			if(mysqli_query($conn,$query))
			{
				echo "row in book_publication inserted";
			}
			else
			{
				echo "error in book_publication insertion";
				echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			}
		}
}

//echo("<br><br>");
print_r($_SESSION);
//header( "refresh:1; url=home.php" );
header( "refresh:1; url=account.php" );  
?>
</body>
</html>