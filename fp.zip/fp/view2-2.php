<?php
include('account.php');
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
#records {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#records td,  th {
    border: 1px solid black;
    padding: 8px;
}

#records tr:nth-child(even){background-color: #f2f2f2;}

#records tr:hover {background-color: #ddd;}

#records th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #DCDCDC;
    color: black;
}


#records td {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: white;
    color: black;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}


hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 

body {
    font-family: "Lato", sans-serif;
    color:black;
}
  
</style>
</head>
<body>
   <br>
   <div>
    <h2 align="center">
  EMPLOYMENT DETAILS-2</h2>
   </div>



<?php
//session_start();
print_r($_SESSION['eid']);
$empid=$_SESSION['eid'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

echo "QUALIFICATION DETAILS <br>";
$sql1= "SELECT * from qualification_details where emp_id='$empid'";
$result1 = $conn->query($sql1);

echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Qualification</th>

<th>Branch</th>

<th>Specialization</th>
<th>University</th>
<th>Percentage</th>
<th>CGPA</th>
<th>Class obtained</th>
<th>Passing year</th>


</tr>";

if ($result1->num_rows > 0) {
    // output data of each row
    while($row1 = $result1->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row1['emp_id'] . "</td>";

  echo "<td>" . $row1['qualification'] . "</td>";

  echo "<td>" . $row1['branch'] . "</td>";

  echo "<td>" . $row1['specialization'] . "</td>";
  echo "<td>" . $row1['university'] . "</td>";
  echo "<td>" . $row1['percentage'] . "</td>";
  echo "<td>" . $row1['cgpa'] . "</td>";
  echo "<td>" . $row1['class_obtained'] . "</td>";
  echo "<td>" . $row1['passing_year'] . "</td>";
  // echo "<td>" . $row1['proof'] . "</td>";
  
  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

echo "TEACHING EXPERIENCE DETAILS<br>";
$sql8= "SELECT * from teacher_experience_details where emp_id='$empid'";
$result8 = $conn->query($sql8);

echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Organization Name  </th>

<th> Designation </th>

<th>Date of joining </th>
<th>Last Date of working</th>
<th>Current pay scale </th>
<th>Grade pay</th>
<th>Nature of appointment </th>
<th>USSC Approved Date</th>
<th>USSC Approved Reference Number</th>
<th>Teaching Experience</th>


</tr>";

if ($result8->num_rows > 0) {
    // output data of each row
    while($row8 = $result8->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row8['emp_id'] . "</td>";

  echo "<td>" . $row8['organization_name'] . "</td>";

  echo "<td>" . $row8['designation'] . "</td>";

  echo "<td>" . $row8['date_of_joining'] . "</td>";
  echo "<td>" . $row8['last_date_of_working'] . "</td>";
  echo "<td>" . $row8['current_pay_scale'] . "</td>";
  echo "<td>" . $row8['grade_pay'] . "</td>";
  echo "<td>" . $row8['nature_of_appointment'] . "</td>";
  echo "<td>" . $row8['ussc_app_date'] . "</td>";
  echo "<td>" . $row8['ussc_ref_no'] . "</td>";
  echo "<td>" . $row8['teaching_exp_years'] . "</td>";
  // echo "<td>" . $row1['proof'] . "</td>";
  
  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

echo "INDUSTRY EXPERIENCE DETAILS<br>";
$sql9= "SELECT * from industry_experience_details where emp_id='$empid'";
$result9 = $conn->query($sql9);

echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Organization Name  </th>

<th> Designation </th>

<th>Date of joining </th>
<th>Last Date of working</th>
<th>Industrial Teaching Experience</th>


</tr>";

if ($result9->num_rows > 0) {
    // output data of each row
    while($row9 = $result9->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row9['emp_id'] . "</td>";

  echo "<td>" . $row9['organization_name'] . "</td>";

  echo "<td>" . $row9['designation'] . "</td>";

  echo "<td>" . $row9['date_of_joining'] . "</td>";
  echo "<td>" . $row9['last_date_of_working'] . "</td>";
  echo "<td>" . $row9['industry_exp_years'] . "</td>";
  // echo "<td>" . $row1['proof'] . "</td>";
  
  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

echo "Research EXPERIENCE DETAILS<br>";
$sql9= "SELECT * from research_experience_details where emp_id='$empid'";
$result9 = $conn->query($sql9);

echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Organization Name  </th>

<th> Designation </th>

<th>Date of joining </th>
<th>Last Date of working</th>
<th>Research Teaching Experience</th>


</tr>";

if ($result9->num_rows > 0) {
    // output data of each row
    while($row9 = $result9->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row9['emp_id'] . "</td>";

  echo "<td>" . $row9['organization_name'] . "</td>";

  echo "<td>" . $row9['designation'] . "</td>";

  echo "<td>" . $row9['date_of_joining'] . "</td>";
  echo "<td>" . $row9['last_date_of_working'] . "</td>";
  echo "<td>" . $row9['research_exp_years'] . "</td>";
  // echo "<td>" . $row1['proof'] . "</td>";
  
  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$sql2= "SELECT * from subject_taught where emp_id='$empid'";
$result2 = $conn->query($sql2);

echo " <br> SUBJECTS TAUGHT <br>";
echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Type of graduation</th>

<th>Subject taught</th>

<th>Period/Year</th>
<th>Subject Experience</th>
<th>Syllabus Revised/Old</th>

</tr>";

if ($result2->num_rows > 0) {
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row2['emp_id'] . "</td>";

  echo "<td>" . $row2['Type_of_graduation'] . "</td>";

  echo "<td>" . $row2['Subject_taught'] . "</td>";

  echo "<td>" . $row2['Peroid_Year'] . "</td>";
  echo "<td>" . $row2['sub_exp'] . "</td>";
  echo "<td>" . $row2['Syllabus'] . "</td>";
  
  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}



echo "<br> PROFESSIONAL MEMBERSHIP DETAILS <br>";

$sql3= "SELECT * from professional_membership where emp_id='$empid'";
$result3 = $conn->query($sql3);

echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Membership Category</th>

<th>Membership number</th>

<th>Body of Organization</th>

</tr>";

if ($result3->num_rows > 0) {
    // output data of each row
    while($row3 = $result3->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row3['emp_id'] . "</td>";

  echo "<td>" . $row3['Membership_category'] . "</td>";

  echo "<td>" . $row3['Membership_no'] . "</td>";

  echo "<td>" . $row3['Body_of_organization'] . "</td>";

  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

echo "<br> INTERACTION WITH OUTSIDE WORLD <br>";

$sql4= "SELECT * from interaction_with_outside_world where emp_id='$empid'";
$result4 = $conn->query($sql4);

echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Interaction Type</th>

<th>Organization</th>

<th>Date</th>

</tr>";

if ($result4->num_rows > 0) {
    // output data of each row
    while($row4 = $result4->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row4['emp_id'] . "</td>";

  echo "<td>" . $row4['Interaction_Type'] . "</td>";

  echo "<td>" . $row4['Organization'] . "</td>";

  echo "<td>" . $row4['Date'] . "</td>";

  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
echo"<br> TRAINING COURSES/ SEMINAR/ WORKSHOP/ CONFERENCE ATTENDED <br>";

$sql5= "SELECT * from training_courses_attended where emp_id='$empid'";
$result5 = $conn->query($sql5);

echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Course Name</th>

<th>Organization Name</th>

<th>Start Date</th>
<th>End Date</th>
<th>Proof</th>

</tr>";

if ($result5->num_rows > 0) {
    // output data of each row
    while($row5 = $result5->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row5['emp_id'] . "</td>";

  echo "<td>" . $row5['course_name'] . "</td>";

  echo "<td>" . $row5['organization_name'] . "</td>";

  echo "<td>" . $row5['start_date'] . "</td>";
  echo "<td>" . $row5['end_date'] . "</td>";
  // echo "<td>" . $row5['proof'] . "</td>";
  
  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

echo"<br> TRAINING COURSES/ SEMINAR/ WORKSHOP/ CONFERENCE ORGANIZED <br>";

$sql6= "SELECT * from training_courses_organize where emp_id='$empid'";
$result6 = $conn->query($sql6);

echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Course Name</th>

<th>Responsibility Handled</th>

<th>Course duration</th>

<th>Proof/Certificate</th>

</tr>";

if ($result6->num_rows > 0) {
    // output data of each row
    while($row6 = $result6->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row6['emp_id'] . "</td>";

  echo "<td>" . $row6['course_name'] . "</td>";

  echo "<td>" . $row6['responsibility'] . "</td>";

  echo "<td>" . $row6['course_duration'] . "</td>";
  
  // echo "<td>" . $row6['proof'] . "</td>";
  
  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

echo " <br> PROJECT GUIDED <br>";

$sql7= "SELECT * from project_guided where emp_id='$empid'";
$result7 = $conn->query($sql7);

echo "<table id='records'>

<tr>

<th>Employee ID</th>

<th>Project Title</th>

<th>Guide Name</th>

<th>Group Members</th>
<th>Department</th>
<th>Year</th>
<th>Student Category</th>
<th>Remarks</th>

</tr>";

if ($result7->num_rows > 0) {
    // output data of each row
    while($row7 = $result7->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";

  echo "<td>" . $row7['emp_id'] . "</td>";

  echo "<td>" . $row7['project_title'] . "</td>";

  echo "<td>" . $row7['guide_name'] . "</td>";

  echo "<td>" . $row7['group_members'] . "</td>";
  echo "<td>" . $row7['dept'] . "</td>";
  echo "<td>" . $row7['year'] . "</td>";
  echo "<td>" . $row7['student_cat'] . "</td>";
  echo "<td>" . $row7['remark'] . "</td>";
  
  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>


