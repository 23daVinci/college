<?php
session_start();
// $servername = "localhost";
// $username1 = "root";
// $passs = "";
// $dbname = "buyit";
// $passvalue = 0;
// // Create connection
// $conn = new mysqli($servername, $username1, $passs, $dbname);
// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// } 

// if (isset($_POST['emailid'])){
// $lfname = $_POST['f1'];
// $llname = $_POST['second'];
// $lemail = $_POST['emailid'];
// $lpass1 = $_POST['p1'];
// $lpass2 = $_POST['p2'];
// $ldob = $_POST['dob'];
// $lgender = $_POST['gender'];
// $laddress = $_POST['address'];
// // $fpass=md5(lpass1);

// }
// //echo "$lfirst";
// //echo "$lpass1";
// //echo "$lpass1";
// // var_dump($lpass1);
// $_SESSION["username"] = $lemail;

// if ($lpass1 == $lpass2) {

// // $sql1 = "  select username, password from login";
// // $result = $conn->query($sql1);

// // if ($result->num_rows > 0) {

// //     // output data of each row
// //     while($row = $result->fetch_assoc()) {
// //     	if ($lemail == $row["username"] && $lpass1 == $row["password"] ) {
// //     		$passvalue = 1;

// //     	}
// //     // 	else
// //     // 		{$passvalue=0;}
// //     // }	
// // } 
// // }

// // if ($passvalue == 0) {
// 	$sql = " insert into customers(fname, lname, email, password, dob, gender, address) values ('$lfname', '$llname', '$lemail', md5('$lpass1'), '$ldob', '$lgender', '$laddress')"; 
// 									if ($conn->query($sql) === TRUE) {
// 								    echo "";
// 								} else {
// 								    echo "Error: " . $sql . "<br>" . $conn->error;
// 								}


// 	$sql = " insert into login(username, password,status) values ('$lemail', md5('$lpass1'),'not verified')"; 
// 									if ($conn->query($sql) === TRUE) {
// 								    echo "";
// 								} else {
// 								    echo "Error: " . $sql . "<br>" . $conn->error;
// 								}

      
      // <?php
         $to = "harshitrai68@gmail.com";
         $subject = "Test Mail";
         
         $message = "<b>This is a test mail sent from ThinkPad E460.</b>";
         $message .= "Delete this message after you've read it.\n";
         $message .= "Thanks for your time.";


         
         $header = "From:kalpana.wani@fcrit.ac.in \r\n";
         $header .= "Cc:hr68.official@gmail.com \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         
         $retval = mail ($to,$subject,$message,$header);
         
         if( $retval == true ) {
            echo "check your mail for further process";
         }else {
            echo "Message could not be sent...";
         }
      

	//header( "refresh:0; url= verification.php ");	
//}
// else{
// 	header( "refresh:0; url= logginform.php ");	
		
// }
// }
//$conn->close();
?>