<?php
include('account.php');
?>

<?php

//session_start();
if(isset($_SESSION['eid']))
{
$empid=$_SESSION['eid'];
//echo $_SESSION['eid'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "SELECT * from qualification_details where emp_id='$empid'";
$result1 = $conn->query($sql);

$count1 = 0;
$Sr_No1 =[];
$qualification=[];
$branch=[];
$specialization=[];
$university=[];
$percentage=[];
$cgpa=[];
$class_obtained=[];
$passing_year=[];
$s=0;

 $sql2= "SELECT * from teacher_experience_details where emp_id='$empid'";
$result2 = $conn->query($sql2);

$count2 = 0;
$Sr_No2 =[];
$Organization_name=[];
$Designation=[];
$Date_of_joining=[];
$Date_of_working=[];
$Current_pay_scale=[];
$Grade_pay=[];
$Nature_of_appointment=[];
$USSC_approval_date=[];
$USSC_approval_ref_no=[];
$Teaching_exp=[];

 $sql3= "SELECT * from industry_experience_details where emp_id='$empid'";
$result3 = $conn->query($sql3);

$count3 = 0;
$Sr_No3 =[];
$Organization_name1=[];
$Designation1=[];
$Date_of_joining1=[];
$Date_of_working1=[];
$Industry_exp=[];


$sql4= "SELECT * from research_experience_details where emp_id='$empid'";
$result4 = $conn->query($sql4);
$Sr_No4 =[];
$Organization_name2=[];
$Designation2=[];
$Date_of_joining2=[];
$Date_of_working2=[];
$Research_exp=[];

$count4 = 0;
 $sql5= "SELECT * from subject_taught where emp_id='$empid'";
$result5 = $conn->query($sql5);

$count5 = 0;
$Sr_No5 =[];
$Type_of_graduation=[];
$Subject_taught=[];
$Period_Year=[];
$sub_exp=[];
$Syllabus=[];


 $sql6= "SELECT * from professional_membership where emp_id='$empid'";
$result6 = $conn->query($sql6);

 $count6 = 0;
 $Sr_No6 =[];
$Membership_category=[];
$Membership_no=[];
$Body_of_organization=[];


 $sql7= "SELECT * from interaction_with_outside_world where emp_id='$empid'";
$result7 = $conn->query($sql7);

$count7 = 0;
$Sr_No7 =[];
$Interaction_type=[];
$Organization=[];
$Date=[];

 
 $sql8= "SELECT * from training_courses_attended where emp_id='$empid'";
$result8 = $conn->query($sql8);

$count8 = 0;
$Sr_No8 =[];
$course_name=[];
$organization_name2=[];
$start_date=[];
$end_date=[];


$sql9= "SELECT * from training_courses_organize where emp_id='$empid'";
$result9 = $conn->query($sql9);

$count9 = 0;
$Sr_No9 =[];
$course_name2=[];
$responsibility=[];
$course_duration=[];

$sql10= "SELECT * from project_guided where emp_id='$empid'";
$result10 = $conn->query($sql10);

$count10 = 0;
$Sr_No10 =[];
$project_title=[];
$guide_name=[];
$group_members=[];
$dept=[];
$year=[];
$student_cat=[];
$remark=[];
 if ($result1->num_rows > 0 || $result2->num_rows > 0 || $result3->num_rows > 0 || $result4->num_rows > 0 || $result5->num_rows > 0 || $result6->num_rows > 0 || $result7->num_rows > 0 || $result8->num_rows > 0 || $result9->num_rows > 0 || $result10->num_rows > 0) {
while($row1 = $result1->fetch_assoc()) {
	$Sr_No1[$count1]=$row1['Sr_no'];
 	$qualification[$count1]=$row1['qualification'];
 	//echo $qualification[$count1];
$branch[$count1]=$row1['branch'];
$specialization[$count1]=$row1['specialization'];
$university[$count1]=$row1['university'];
$percentage[$count1]=$row1['percentage'];
$cgpa[$count1]=$row1['cgpa'];
$class_obtained[$count1]=$row1['class_obtained'];
$passing_year[$count1]=$row1['passing_year'];
//echo $passing_year[$count1];
 	$count1++;
 }
while($row2 = $result2->fetch_assoc()) {
	$Sr_No2[$count2]=$row2['Sr_no'];
 	$Organization_name[$count2]=$row2['organization_name'];
$Designation[$count2]=$row2['designation'];
//echo $Designation[$count2];
$Date_of_joining[$count2]=$row2['date_of_joining'];
$Date_of_working[$count2]=$row2['last_date_of_working'];
$Current_pay_scale[$count2]=$row2['current_pay_scale'];
//echo $Current_pay_scale[$count2];
$Grade_pay[$count2]=$row2['grade_pay'];
//echo $Grade_pay[$count3];
$Nature_of_appointment[$count2]=$row2['nature_of_appointment'];
$USSC_approval_date[$count2]=$row2['ussc_app_date'];
$USSC_approval_ref_no[$count2]=$row2['ussc_ref_no'];
$Teaching_exp[$count2]=$row2['teaching_exp_years'];

 	$count2++;
 }
 while($row3 = $result3->fetch_assoc()) {
 	$Sr_No3[$count3]=$row3['Sr_no'];
 	$Organization_name1[$count3]=$row3['organization_name'];
$Designation1[$count3]=$row3['designation'];
//echo $Designation[$count2];
$Date_of_joining1[$count3]=$row3['date_of_joining'];
$Date_of_working1[$count3]=$row3['last_date_of_working'];
$Industry_exp[$count3]=$row3['industry_exp_years'];
$count3++;
 }
while($row4 = $result4->fetch_assoc()) {
 	$Sr_No4[$count4]=$row4['Sr_no'];
 	$Organization_name2[$count4]=$row4['organization_name'];
$Designation2[$count4]=$row4['designation'];
//echo $Designation[$count2];
$Date_of_joining2[$count4]=$row4['date_of_joining'];
$Date_of_working2[$count4]=$row4['last_date_of_working'];
$Research_exp[$count4]=$row4['research_exp_years'];
$count4++;
 }
while($row5 = $result5->fetch_assoc()) {
 	$Sr_No5[$count5]=$row5['Sr_no'];
 	echo $Sr_No5[$count5];
 	$Type_of_graduation[$count5]=$row5['Type_of_graduation'];
$Subject_taught[$count5]=$row5['Subject_taught'];
$Period_Year[$count5]=$row5['Peroid_Year'];
$sub_exp[$count5]=$row5['sub_exp'];
$Syllabus[$count5]=$row5['Syllabus'];
 	$count5++;
 }
while($row6 = $result6->fetch_assoc()) {
 	$Sr_No6[$count6]=$row6['Sr_no'];
 	$Membership_category[$count6]=$row6['Membership_category'];
$Membership_no[$count6]=$row6['Membership_no'];
$Body_of_organization[$count6]=$row6['Body_of_organization'];
 	$count6++;
 }
while($row7 = $result7->fetch_assoc()) {
 	$Sr_No7[$count7]=$row7['Sr_no'];
 	$Interaction_type[$count7]=$row7['Interaction_Type'];
 	//echo $Interaction_type[$count7];
$Organization[$count7]=$row7['Organization'];
$Date[$count7]=$row7['Date'];
 	$count7++;
 }
while($row8 = $result8->fetch_assoc()) {
 	$Sr_No8[$count8]=$row8['Sr_no'];
 	//echo $Sr_No8[$count8];
 	$course_name[$count8]=$row8['course_name'];
 	//echo $course_name[$count8];
$organization_name2[$count8]=$row8['organization_name'];
$start_date[$count8]=$row8['start_date'];
$end_date[$count8]=$row8['end_date'];
 	$count8++;
 }
while($row9 = $result9->fetch_assoc()) {
 	$Sr_No9[$count9]=$row9['Sr_no'];
 	$course_name2[$count9]=$row9['course_name'];
$responsibility[$count9]=$row9['responsibility'];
$course_duration[$count9]=$row9['course_duration'];
 	$count9++;
 }


 while($row10 = $result10->fetch_assoc()) {
 	$Sr_No10[$count10]=$row10['Sr_no'];
 	$project_title[$count10]=$row10['project_title'];
$guide_name[$count10]=$row10['guide_name'];
$group_members[$count10]=$row10['group_members'];
$dept[$count10]=$row10['dept'];
$year[$count10]=$row10['year'];
$student_cat[$count10]=$row10['student_cat'];
$remark[$count10]=$row10['remark'];
 	$count10++;
 }
}
else
{
	header("Location:stage4.php");
}

 }
else
{
	$code = 403;
	header("Location: alert.php?code=$code");
}
//print_r($Designation);

?>
<html>
<head>
<title>Staff Employment Details</title>
<style>
	body{
		color:black !important;
	}
	input{
		width:100%;
	}
	#myProgress {
		width: 100%;
		background-color: #ddd;
	}
	#myBar {
		width: 16.66%;
		height: 30px;
		background-color: #4CAF50;
}
</style>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<script language='javascript'>


  var id=599;                                                          //id for table1
  var rid=1399;                                                       //id for table2
  //var t21id=1999;
  var t3id=2299;
  var t4id=2599;
  var t5id=2999;
  var t6id=3499;
  var t7id=3999;
  var t8id=4499;
  var t9id = 5599;
  var t10id = 6699;
  
  
  // function to validate table1 -- QUALIFICATION DETAILS
  function check(field){
	  //id value for element
    var i1 = Number(field.id)+1;           
	var i2 = i1+1;                          
	var i3 = i1+2;
	var i4 = i1+3;
	var i5 = i1+4;
	var i6 = i1+5;
	var i7 = i1+6;
	var i8 = i1+7;
	var i9 = i1+8;
	//retrieving element by ids
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	var s3=document.getElementById(i3);
	var s4=document.getElementById(i4);
	var s5=document.getElementById(i5);
	var s6=document.getElementById(i6);
	var s7=document.getElementById(i7);
	var s8=document.getElementById(i8);
	var s9=document.getElementById(i9);
	//disabling fields if value of paper title is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s3.value = "";	
	s4.value = "";
	s5.value = "";
	s6.value = "";
	s7.value = "";
	s8.value = "";
	s9.value = "";
	s1.disabled = true;
	s2.disabled = true;
  	s3.disabled = true;
	s4.disabled = true;
	s5.disabled = true;
	s6.disabled = true;
	s7.disabled = true;
	s8.disabled = true;
	s9.disabled = true;
    return 0;	
	}
	//enabling fields if value of paper title is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	s4.disabled = false;
	s5.disabled = false;
	s6.disabled = false;
	s7.disabled = false;
	s8.disabled = false;
	s9.disabled = false;
    return 0;		
	}
  }
 //jaya gupta
 // function for teacher exp Details
 function check1(field){
	  // id for element
    var i1 = Number(field.id)+1;
	var i2 = i1+1;
	var i3 = i1+2;
	var i4 = i1+3;
	var i5 = i1+4;
	var i6 = i1+5;
	var i7 = i1+6;
	var i8 = i1+7;
	var i9 = i1+8;
	//var i10 = i1+9;
	//var i11 = i1+10;

	
	
	// retrieving element by ids
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	var s3=document.getElementById(i3);
	var s4=document.getElementById(i4);
	var s5=document.getElementById(i5);
	var s6=document.getElementById(i6);
	var s7=document.getElementById(i7);
	var s8=document.getElementById(i8);
	var s9=document.getElementById(i9);
	//var s10=document.getElementById(i10);
	//var s11=document.getElementById(i11);
	
	//disabling fields if value of name of book is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s3.value = "";
	s4.value = "";
	s5.value = "";
	s6.value = "";
	s7.value = "";
	s8.value = "";
	s9.value = "";
	//s10.value = "";
	//s11.value = "";
	s1.disabled = true;
	s2.disabled = true;
  	s3.disabled = true;
	s4.disabled = true;
	s5.disabled = true;
	s6.disabled = true;
	s7.disabled = true;
	s8.disabled = true;
	s9.disabled = true;
	//s10.disabled = true;
	//s11.disabled = true;
  	return 0;	
	}
	//enabling fields if value of name of book is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	s4.disabled = false;
	s5.disabled = false;
	s6.disabled = false;
	s7.disabled = false;
	s8.disabled = false;
	s9.disabled = false;
	//s10.disabled = false;
	//s11.disabled = false;
	return 0;		
	}
  }
  
  
    // function to validate table21 -- Research details
  function check9(field){
	  //id value for element
    var i1 = Number(field.id)+1;           
	var i2 = i1+1;                          
	var i3 = i1+2;
	var i4 = i1+3;
	var i5 = i1+4;
	//retrieving element by ids
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	var s3=document.getElementById(i3);
	var s4=document.getElementById(i4);
	var s5=document.getElementById(i5);
	//disabling fields if value of paper title is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s3.value = "";	
	s4.value = "";
	s5.value = "";
	s1.disabled = true;
	s2.disabled = true;
  	s3.disabled = true;
	s4.disabled = true;
	s5.disabled = true;
	 return 0;	
	}
	//enabling fields if value of paper title is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	s4.disabled = false;
	s5.disabled = false;
	return 0;		
	}
  }

 function check10(field){
	  //id value for element
    var i1 = Number(field.id)+1;           
	var i2 = i1+1;                          
	var i3 = i1+2;
	var i4 = i1+3;
	var i5 = i1+4;
	//retrieving element by ids
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	var s3=document.getElementById(i3);
	var s4=document.getElementById(i4);
	var s5=document.getElementById(i5);
	//disabling fields if value of paper title is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s3.value = "";	
	s4.value = "";
	s5.value = "";
	s1.disabled = true;
	s2.disabled = true;
  	s3.disabled = true;
	s4.disabled = true;
	s5.disabled = true;
	 return 0;	
	}
	//enabling fields if value of paper title is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	s4.disabled = false;
	s5.disabled = false;
	return 0;		
	}
  }

  function check2(field){
	  // id for element -- subs_taught
    var i1 = Number(field.id)+1;
	var i2 = i1+1;
	var i3 = i1+2;
	var i4 = i1+3;
	// retrieving element by ids
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	var s3=document.getElementById(i3);
	var s4=document.getElementById(i4);
	//disabling fields if value of name of book is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s3.value = "";	
	s4.value = "";
	s1.disabled = true;
	s2.disabled = true;
  	s3.disabled = true;
	s4.disabled = true;
	return 0;	
	}
	//enabling fields if value of name of book is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	s4.disabled = false;
	return 0;		
	}
  }

  function check3(field){
	var i1 = Number(field.id)+1;
	var i2 = i1+1;
	// retrieving element by ids -- PROFESSIONAL MEMBERSHIP DETAILS
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	//disabling fields if value of name of book is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s1.disabled = true;
	s2.disabled = true;
  	return 0;	
	}
	//enabling fields if value of name of book is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	return 0;		
	}  
  }
  
  // function for INTERACTION WITH OUTSIDE WORLD
  function check4(field){
	  //id value for element -- INTERACTION WITH OUTSIDE WORLD
    var i1 = Number(field.id)+1;           
	var i2 = i1+1;                          
	//var i3 = i1+2;
	//var i4 = i1+3;
	//var i5 = i1+4;
	//retrieving element by ids
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	//var s3=document.getElementById(i3);
	//var s4=document.getElementById(i4);
	//var s5=document.getElementById(i5);
	//disabling fields if value of paper title is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	//s3.value = "";	
	//s4.value = "";
	//s5.value = "";
	s1.disabled = true;
	s2.disabled = true;
  	//s3.disabled = true;
	//s4.disabled = true;
	//s5.disabled = true;
	return 0;	
	}
	//enabling fields if value of paper title is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	//s3.disabled = false;
	//s4.disabled = false;
	//s5.disabled = false;
    return 0;		
	}
  }
  

  //function for TRAINING COURSES/ SEMINAR/ WORKSHOP/ CONFERENCE ATTENDED
 function check5(field){
	  //id value for element
    var i1 = Number(field.id)+1;           
	var i2 = i1+1;                          
	var i3 = i1+2;
	var i4 = i1+3;
	var i5 = i1+4;
	//var i6 = i1+5;//jaya
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	var s3=document.getElementById(i3);
	var s4=document.getElementById(i4);
	var s5=document.getElementById(i5);
	//var s6=document.getElementById(i6);//jaya
	//disabling fields if value of paper title is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s3.value = "";	
	s4.value = "";
	s5.value = "";
	//s6.value = "";//jaya
	s1.disabled = true;
	s2.disabled = true;
  	s3.disabled = true;
	s4.disabled = true;
	s5.disabled = true;	
	//s6.disabled = true;//jaya
	return 0;	
	}
	//enabling fields if value of paper title is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	s4.disabled = false;
	s5.disabled = false;
    return 0;		
	}
  }
  
  //smita 
   //function for PROJECT GUIDED
 function check5(field){
	  //id value for element
    var i1 = Number(field.id)+1;           
	var i2 = i1+1;                          
	var i3 = i1+2;
	var i4 = i1+3;
	var i5 = i1+4;
	var i6 = i1+5;//jaya
	var s1=document.getElementById(i1);
	var s2=document.getElementById(i2);
	var s3=document.getElementById(i3);
	var s4=document.getElementById(i4);
	var s5=document.getElementById(i5);
	var s6=document.getElementById(i6);
	//disabling fields if value of paper title is null
	if(field.value==""){
	s1.value = "";	
	s2.value = "";
	s3.value = "";	
	s4.value = "";
	s5.value = "";
	s6.value = "";
	s1.disabled = true;
	s2.disabled = true;
  	s3.disabled = true;
	s4.disabled = true;
	s5.disabled = true;	
	s6.disabled = true;
	return 0;	
	}
	//enabling fields if value of paper title is not null
	else{
	s1.disabled = false;
	s2.disabled = false;
  	s3.disabled = false;
	s4.disabled = false;
	s5.disabled = false;
	s6.disabled = false;
    return 0;		
	}
  }


  function addrow(tableID,i) {
          
			var table = document.getElementById(tableID);   
			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell0 = row.insertCell(0);                              //checkbox
			var element0 = document.createElement('input');
			element0.type = 'checkbox';
			element0.name = 'qualific_details_'+rowCount+'[]';
			element0.id =id+1;
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)                                 //label for numbering  
			var element1 = document.createElement('label');
			element1.id = id+2;
			cell1.style.cssText = "text-align:center";
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);                              //text field for paper title
			var element2 = document.createElement('input');
			element2.type = 'text';
			element2.id=id+3;
			element2.name='qualific_details_'+rowCount+'[]';
			element2.placeholder='Qualification';
			var users = <?php echo json_encode($qualification); ?>; 
			if((rowCount)<=users.length){
				element2.value = users[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);                              //select element for category
			var element3 = document.createElement('input');
			element3.type = 'text';
			element3.id=id+4;
			element3.name='qualific_details_'+rowCount+'[]';
			element3.placeholder='Branch';
			var users = <?php echo json_encode($branch); ?>; 
			if((rowCount)<=users.length){
				element3.value = users[i];
			}
			else{
				element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			cell3.appendChild(element3);
			
			
			var cell4 = row.insertCell(4);          
			var element4 = document.createElement('input');               //date
			element4.type = 'text';
			element4.id=id+5;
			element4.name='qualific_details_'+rowCount+'[]';
			element4.placeholder='Specialization';
			var users = <?php echo json_encode($specialization); ?>; 
			if((rowCount)<=users.length){
				element4.value = users[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);
			
			var cell5 = row.insertCell(5);
			var element5 = document.createElement('input');               
			element5.type = 'text';
			element5.id=id+6;
			element5.name='qualific_details_'+rowCount+'[]';
			element5.placeholder='University/Board';
			var users = <?php echo json_encode($university); ?>; 
			if((rowCount)<=users.length){
				element5.value = users[i];
			}
			else{
				element5.value = "";
				element5.required=true;
				element5.disabled=true;
			}
			cell5.appendChild(element5);
			
			var cell6 = row.insertCell(6);          
			var element6 = document.createElement('input');               //date
			element6.type = 'text';
			element6.id=id+7;
			element6.name='qualific_details_'+rowCount+'[]';
			element6.placeholder='Percentage';
			var users = <?php echo json_encode($percentage); ?>; 
			if((rowCount)<=users.length){
				element6.value = users[i];
			}
			else{
				element6.value = "";
				element6.required=true;
				element6.disabled=true;
			}
			cell6.appendChild(element6);
			
			var cell7 = row.insertCell(7);          
			var element7 = document.createElement('input');               //date
			element7.type = 'text';
			element7.id=id+8;
			element7.name='qualific_details_'+rowCount+'[]';
			element7.placeholder='CGPA';
			var users = <?php echo json_encode($cgpa); ?>; 
			if((rowCount)<=users.length){
				element7.value = users[i];
			}
			else{
				element7.value = "";
				element7.required=true;
				element7.disabled=true;
			}
			cell7.appendChild(element7);
			
			var cell8 = row.insertCell(8);          
			var element8 = document.createElement('input');               //date
			element8.type = 'text';
			element8.id=id+9;
			element8.name='qualific_details_'+rowCount+'[]';
			element8.placeholder='class';
			var users = <?php echo json_encode($class_obtained); ?>; 
			if((rowCount)<=users.length){
				element8.value = users[i];
			}
			else{
				element8.value = "";
				element8.required=true;
				element8.disabled=true;
			}
			 cell8.appendChild(element8);
	
			var cell9 = row.insertCell(9);          
			var element9 = document.createElement('input');               //date
			element9.type = 'text';
			element9.id=id+10;
			element9.name='qualific_details_'+rowCount+'[]';
			element9.placeholder='Passing Year';
			var users = <?php echo json_encode($passing_year); ?>; 
			if((rowCount)<=users.length){
				element9.value = users[i];
			}
			else{
				element9.value = "";
				element9.required=true;
				element9.disabled=true;
			}
			 cell9.appendChild(element9);
			
			var element10 = document.createElement("input");
			element10.type = 'hidden';
			element10.name = 'qualific_details_'+rowCount+'[]';//Name of table 
			element10.id = rid+11;
			var users = <?php echo json_encode($Sr_No1); ?>;
			console.log(users.length);
			if(rowCount<=users.length){
				element10.setAttribute("value", users[i]);
			}
			else{
	    		element10.setAttribute("value", "a");
			}
			cell9.appendChild(element10);
	
        id=id+11;   
		}
	//function to add rows in Experience Details	
	// function addrow1(tableID,i) {
          
	// 		var table = document.getElementById(tableID);

	// 		var rowCount = table.rows.length;
	// 		var row = table.insertRow(rowCount);

	// 		var cell0 = row.insertCell(0); 
	// 		var element0 = document.createElement('input');                //checkbox
	// 		element0.type = 'checkbox';
	// 		element0.name = 'teacher_exp_details_'+rowCount+'[]';
	// 		element0.id =rid+1;
	// 		cell0.appendChild(element0);
			
	// 		var cell1 =row.insertCell(1)
	// 		var element1 = document.createElement('label');                 // label for numbering
	// 		element1.id = rid+2;
	// 		cell1.innerHTML = rowCount;
	// 		cell1.appendChild(element1);
			
	// 		var cell2 = row.insertCell(2);
	// 		var element2 = document.createElement('input');                 //text field for name       
	// 		element2.type = 'text';
	// 		element2.id=rid+3;
	// 		element2.name='teacher_exp_details_'+rowCount+'[]';
	// 		element2.placeholder='Organization Name';
	// 		var users = <?php echo json_encode($Organization_name); ?>; 
	// 		////console.log(users);
	// 		if((rowCount)<=users.length){
	// 			element2.value = users[i];
	// 		}
	// 		else{
	// 			element2.value = "";
	// 			element2.setAttribute("onchange",'javascript:check1(this)');
	// 		}
	// 		cell2.appendChild(element2);

	// 		var cell3 = row.insertCell(3);
	// 		var element3 = document.createElement('input');                  //text field for aurthor
	// 		element3.type='text';
	// 		element3.id=rid+4;
	// 		element3.name='teacher_exp_details_'+rowCount+'[]';
	// 		element3.placeholder='Desgination';
	// 		var users = <?php echo json_encode($Designation); ?>;
	// 		if((rowCount)<=users.length){
	// 			element3.value = users[i];
	// 		}
	// 		else{
	// 			element3.value = "";
	// 			element3.required=true;
	// 			element3.disabled=true;
	// 		}
	// 		cell3.appendChild(element3);
			
	// 		var cell4 = row.insertCell(4);
	// 		var element4 = document.createElement('input');                 //text field for publisher  
	// 		element4.type = 'Date';
	// 		element4.id=rid+5;
	// 		element4.name='teacher_exp_details_'+rowCount+'[]';
	// 		element4.placeholder='dd/mm/yyyy';
	// 		var users = <?php echo json_encode($Date_of_joining); ?>;
	// 		if((rowCount)<=users.length){
	// 			element4.value = users[i];
	// 		}
	// 		else{
	// 			element4.value = "";
	// 			element4.required=true;
	// 			element4.disabled=true;
	// 		}
	// 		cell4.appendChild(element4);
			
	// 		var cell5 = row.insertCell(5);
	// 		var element5 = document.createElement('input');                 //text field for year
	// 		element5.type = 'Date';
	// 		element5.id=rid+6;
	// 		element5.name='teacher_exp_details_'+rowCount+'[]';
	// 		element5.placeholder='dd/mm/yyyy';
	// 		var users = <?php echo json_encode($Date_of_working); ?>;
	// 		if((rowCount)<=users.length){
	// 			element5.value = users[i];
	// 		}
	// 		else{
	// 			element5.value = "";
	// 			element5.required=true;
	// 			element5.disabled=true;
	// 		}
	// 		cell5.appendChild(element5);

	// 		var cell6 = row.insertCell(6);
	// 		var element6 = document.createElement('input');     
	// 		element6.type = 'text';             //text field for Principal
	// 		element6.id=rid+7;
	// 		element6.name='teacher_exp_details_'+rowCount+'[]';
	// 		element6.placeholder='Current Pay';
	// 		element6.style.cssText="width:100%";
	// 		var users = <?php echo json_encode($Current_pay_scale); ?>;
	// 		////console.log(users[i]);
	// 		if((rowCount)<=users.length){
	// 			element6.value = users[i];
	// 		}
	// 		else{
	// 			element6.value = "";
	// 			element6.required=true;
	// 			element6.disabled=true;
	// 		}
	// 		cell6.appendChild(element6);

	// 		var cell7 = row.insertCell(7);
	// 		var element7 = document.createElement('input');     
	// 		element7.type = 'text';             //text field for Principal
	// 		element7.id=rid+8;
	// 		element7.name='teacher_exp_details_'+rowCount+'[]';
	// 		element7.placeholder='Grade Pay';
	// 		element7.style.cssText="width:100%";
	// 		var users = <?php echo json_encode($Grade_pay); ?>;
	// 		////console.log(users);
	// 		if((rowCount)<=users.length){
	// 			element7.value = users[i];
	// 		}
	// 		else{
	// 			element7.value = "";
	// 			element7.required=true;
	// 			element7.disabled=true;
	// 		}
	// 		cell7.appendChild(element7);
			
	// 		var cell8 = row.insertCell(8);
	// 		var element8 = document.createElement('select');                 //text field for year
	// 		element8.id=rid+9;
	// 		element8.name='teacher_exp_details_'+rowCount+'[]';
	// 		element8.placeholder='appointment';
	// 		var visitor = <?php echo json_encode($Nature_of_appointment); ?>;
	// 		console.log(visitor.length,rowCount);
	// 		if((rowCount)>=visitor.length){
	// 			var option1 = document.createElement("option");              //option none  
	// 			option1.innerHTML = "None";
	// 			option1.value = "";
	// 	    	element8.appendChild(option1);
	// 	    	element8.required=true;
	// 	    	element8.disabled=true;
	// 		}
			
	// 		var option2 = document.createElement("option");              //option none  
	// 		option2.innerHTML = "USSC Approved";
	// 		option2.value = "USSC Approved";
	// 		////console.log(visitor);
	// 		if((rowCount)<=visitor.length && option2.value == visitor[i]){
	// 			 option2.selected=true;
	// 		}
	// 		else{
	// 			option2.selected=false;
	// 		}
	// 	    // element8.appendChild(option2);
			
	// 		var option3 = document.createElement("option");              //option none  
	// 		option3.innerHTML = "Regular";
	// 		option3.value = "Regular";
	// 		if((rowCount)<=visitor.length && option3.value == visitor[i]){
	// 			 option3.selected=true;
	// 		}
	// 		else{
	// 			option3.selected=false;
	// 		}
	// 	    // element8.appendChild(option3);
			
	// 		var option4 = document.createElement("option");              //option none  
	// 		option4.innerHTML = "Adhoc";
	// 		option4.value = "Adhoc";
	// 		if((rowCount)<=visitor.length && option4.value == visitor[i]){
	// 			 option4.selected=true;
	// 		}
	// 		else{
	// 			option4.selected=false;
	// 		}
	// 	    // element8.appendChild(option4);
			
	// 		var option5 = document.createElement("option");              //option none  
	// 		option5.innerHTML = "Visiting";
	// 		option5.value = "Visiting";
	// 		if((rowCount)<=visitor.length && option5.value == visitor[i]){
	// 			 option5.selected=true;
	// 		}
	// 		else{
	// 			option5.selected=false;
	// 		}
	// 	    // element8.appendChild(option5);
			
	// 		var option6 = document.createElement("option");              //option none  
	// 		option6.innerHTML = "Probation";
	// 		option6.value = "Probation";
	// 		if((rowCount)<=visitor.length && option6.value == visitor[i]){
	// 			 option6.selected=true;
	// 		}
	// 		else{
	// 			option6.selected=false;
	// 		}
	// 	    // element8.appendChild(option6);
			
			
	// 		element8.style.cssText="width:100%";
	// 		// element8.appendChild(option1);
	// 		element8.appendChild(option2);
	// 		element8.appendChild(option3);
	// 		element8.appendChild(option4);
	// 		element8.appendChild(option5);
	// 		element8.appendChild(option6);
			
	// 		cell8.appendChild(element8);

	// 		var cell9 = row.insertCell(9);
	// 		var element9 = document.createElement('input');                 //text field for year
	// 		element9.type = 'Date';
	// 		element9.id=rid+10;
	// 		element9.name='teacher_exp_details_'+rowCount+'[]';
	// 		element9.placeholder='dd/mm/yyyy';
	// 		var users = <?php echo json_encode($USSC_approval_date); ?>;
	// 		if((rowCount)<=users.length){
	// 			element9.value = users[i];
	// 		}
	// 		else{
	// 			element9.value = "";
	// 			element9.required=true;
	// 			element9.disabled=true;
	// 		}
	// 		cell9.appendChild(element9);
			
			
	// 		var cell10 = row.insertCell(10);
	// 		var element10 = document.createElement('input');                 //text field for year
	// 		element10.type = 'text';
	// 		element10.id=rid+11;
	// 		element10.name='teacher_exp_details_'+rowCount+'[]';
	// 		element10.placeholder='Approval no';
	// 		var users = <?php echo json_encode($USSC_approval_ref_no); ?>;
	// 		if((rowCount)<=users.length){
	// 			element10.value = users[i];
	// 		}
	// 		else{
	// 			element10.value = "";
	// 			element10.required=true;
	// 			element10.disabled=true;
	// 		}
	// 		element10.style.cssText="width:100%";
	// 		cell10.appendChild(element10);
			
 //            var cell11 = row.insertCell(11);
	// 		var element11 = document.createElement('input');                 //text field for Project Title       
	// 		element11.type = 'text';
	// 		element11.id=rid+12;
	// 		element11.name='teacher_exp_details_'+rowCount+'[]';
	// 		element11.placeholder='Teaching Experience in Years';
	// 		element11.style.cssText="width:100%";
	// 		var users = <?php echo json_encode($Teaching_exp); ?>;
	// 		//console.log(users);
	// 		if((rowCount)<=users.length){
	// 			element11.value = users[i];
	// 		}
	// 		else{
	// 			element11.value = "";
	// 			element11.required=true;
	// 			element11.disabled=true;
	// 		}
	// 		//element11.setAttribute("onchange",'javascript:check1(this)');
	// 		cell11.appendChild(element11);
			
			
	// 		var element12 = document.createElement("input");
	// 		element12.type = 'hidden';
	// 		element12.name = 'teacher_exp_details_'+rowCount+'[]';//Name of table 
	// 		element12.id = rid+13;
	// 		var users = <?php echo json_encode($Sr_No2); ?>;
	// 		if(rowCount<=users.length){
	// 			element12.setAttribute("value", users[i]);
	// 		}
	// 		else{
	// 		element12.setAttribute("value", "a");
	// 		}
	// 		cell11.appendChild(element12);


	// 		rid=rid+13;
	// 	}

	function addrow1(tableID,i) {
          
			var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell0 = row.insertCell(0); 
			var element0 = document.createElement('input');                //checkbox
			element0.type = 'checkbox';
			element0.name = 'teacher_exp_details_'+rowCount+'[]';
			element0.id =rid+1;
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)
			var element1 = document.createElement('label');                 // label for numbering
			element1.id = rid+2;
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);
			var element2 = document.createElement('input');                 //text field for name       
			element2.type = 'text';
			element2.id=rid+3;
			element2.name='teacher_exp_details_'+rowCount+'[]';
			element2.placeholder='Organization Name';
			var users = <?php echo json_encode($Organization_name); ?>; 
			////console.log(users);
			if((rowCount)<=users.length){
				element2.value = users[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check1(this)');
			}
			//element2.setAttribute("onchange",'javascript:check1(this)');
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);
			var element3 = document.createElement('input');                  //text field for aurthor
			element3.type='text';
			element3.id=rid+4;
			element3.name='teacher_exp_details_'+rowCount+'[]';
			element3.placeholder='Desgination';
			//element3.required=true;
			//element3.disabled=true;
			var users = <?php echo json_encode($Designation); ?>;
			if((rowCount)<=users.length){
				element3.value = users[i];
			}
			else{
				element3.value = "";
				element3.required = true;
				element3.disabled = true;
			}
			cell3.appendChild(element3);
			
			var cell4 = row.insertCell(4);
			var element4 = document.createElement('input');                 //text field for publisher  
			element4.type = 'Date';
			element4.id=rid+5;
			element4.name='teacher_exp_details_'+rowCount+'[]';
			element4.placeholder='dd/mm/yyyy';
			//element4.required=true;
			//element4.disabled=true;
			var users = <?php echo json_encode($Date_of_joining); ?>;
			if((rowCount)<=users.length){
				element4.value = users[i];
			}
			else{
				element4.value = "";
				element4.required = true;
				element4.disabled = true;
			}
			cell4.appendChild(element4);
			
			var cell5 = row.insertCell(5);
			var element5 = document.createElement('input');                 //text field for year
			element5.type = 'Date';
			element5.id=rid+6;
			element5.name='teacher_exp_details_'+rowCount+'[]';
			element5.placeholder='dd/mm/yyyy';
			//element5.required=true;
			//element5.disabled=true;
			var users = <?php echo json_encode($Date_of_working); ?>;
			if((rowCount)<=users.length){
				element5.value = users[i];
			}
			else{
				element5.value = "";
				element5.required = true;
				element5.disabled = true;
			}
			cell5.appendChild(element5);

			var cell6 = row.insertCell(6);
			var element6 = document.createElement('input');     
			element6.type = 'text';             //text field for Principal
			element6.id=rid+7;
			element6.name='teacher_exp_details_'+rowCount+'[]';
			element6.placeholder='Current Pay';
			//element6.required=true;
			//element3.disabled=true;
			element6.style.cssText="width:100%";
			var users = <?php echo json_encode($Current_pay_scale); ?>;
			////console.log(users[i]);
			if((rowCount)<=users.length){
				element6.value = users[i];
			}
			else{
				element6.value = "";
				element6.required = true;
				element6.disabled = true;
			}
			cell6.appendChild(element6);

			var cell7 = row.insertCell(7);
			var element7 = document.createElement('input');     
			element7.type = 'text';             //text field for Principal
			element7.id=rid+8;
			element7.name='teacher_exp_details_'+rowCount+'[]';
			element7.placeholder='Grade Pay';
			//element7.required=true;
			//element3.disabled=true;
			element7.style.cssText="width:100%";
			var users = <?php echo json_encode($Grade_pay); ?>;
			////console.log(users);
			if((rowCount)<=users.length){
				element7.value = users[i];
			}
			else{
				element7.value = "";
				element7.required = true;
				element7.disabled = true;
			}
			cell7.appendChild(element7);
			
			var cell8 = row.insertCell(8);
			var element8 = document.createElement('select');                 //text field for year
			element8.id=rid+9;
			element8.name='teacher_exp_details_'+rowCount+'[]';
			element8.placeholder='appointment';
			var visitor = <?php echo json_encode($Nature_of_appointment); ?>;
			if((rowCount)>visitor.length){
				var option1 = document.createElement("option");              //option none  
				option1.innerHTML = "None";
				option1.value = "";
				option1.disabled=true;
	        	option1.selected=true;
	        	element8.required=true;
				element8.disabled=true;
		    	element8.appendChild(option1);
			}
			
			
			var option2 = document.createElement("option");              //option none  
			option2.innerHTML = "USSC Approved";
			option2.value = "USSC Approved";
			////console.log(visitor);
			if((rowCount)<=visitor.length && option2.value == visitor[i]){
				 option2.selected=true;
			}
			else{
				option2.selected=false;
			}
		    // element8.appendChild(option2);
			
			var option3 = document.createElement("option");              //option none  
			option3.innerHTML = "Regular";
			option3.value = "Regular";
			if((rowCount)<=visitor.length && option3.value == visitor[i]){
				 option3.selected=true;
			}
			else{
				option3.selected=false;
			}
		    // element8.appendChild(option3);
			
			var option4 = document.createElement("option");              //option none  
			option4.innerHTML = "Adhoc";
			option4.value = "Adhoc";
			if((rowCount)<=visitor.length && option4.value == visitor[i]){
				 option4.selected=true;
			}
			else{
				option4.selected=false;
			}
		    // element8.appendChild(option4);
			
			var option5 = document.createElement("option");              //option none  
			option5.innerHTML = "Visiting";
			option5.value = "Visiting";
			if((rowCount)<=visitor.length && option5.value == visitor[i]){
				 option5.selected=true;
			}
			else{
				option5.selected=false;
			}
		    // element8.appendChild(option5);
			
			var option6 = document.createElement("option");              //option none  
			option6.innerHTML = "Probation";
			option6.value = "Probation";
			if((rowCount)<=visitor.length && option6.value == visitor[i]){
				 option6.selected=true;
			}
			else{
				option6.selected=false;
			}
		    // element8.appendChild(option6);
			
			
			element8.style.cssText="width:100%";
			// element8.appendChild(option1);
			element8.appendChild(option2);
			element8.appendChild(option3);
			element8.appendChild(option4);
			element8.appendChild(option5);
			element8.appendChild(option6);
			
			cell8.appendChild(element8);
			
			var cell9 = row.insertCell(9);
			var element9 = document.createElement('input');                 //text field for year
			element9.type = 'date';
			element9.id=rid+10;
			element9.name='teacher_exp_details_'+rowCount+'[]';
			element9.placeholder='Approval Date';
			element9.style.cssText="width:100%";
			//element9.required=true;
			//element5.disabled=true;
			var users = <?php echo json_encode($USSC_approval_date); ?>;
			////console.log(users);
			if((rowCount)<=users.length){
				element9.value = users[i];
			}
			else{
				element9.value = "";
				element9.required = true;
				element9.disabled = true;
			}
			cell9.appendChild(element9);
			
			var cell10 = row.insertCell(10);
			var element10 = document.createElement('input');                 //text field for year
			element10.type = 'text';
			element10.id=rid+11;
			element10.name='teacher_exp_details_'+rowCount+'[]';
			element10.placeholder='Approval no';
			//element10.required=true;
			//element6.disabled=true;
			var users = <?php echo json_encode($USSC_approval_ref_no); ?>;
			//console.log(users);
			if((rowCount)<=users.length){
				element10.value = users[i];
			}
			else{
				element10.value = "";
				element10.required = true;
				element10.disabled = true;
			}
			element10.style.cssText="width:100%";

			cell10.appendChild(element10);
			
           var cell11 = row.insertCell(11);
			var element11 = document.createElement('input');                 //text field for Project Title       
			element11.type = 'text';
			element11.id=rid+12;
			element11.name='teacher_exp_details_'+rowCount+'[]';
			element11.placeholder='Teaching Experience in Years';
			element11.style.cssText="width:100%";
			var users = <?php echo json_encode($Teaching_exp); ?>;
			//console.log(users);
			if((rowCount)<=users.length){
				element11.value = users[i];
			}
			else{
				element11.value = "";
				element11.required = true;
				element11.disabled = true;
			}
			//element11.setAttribute("onchange",'javascript:check1(this)');
			cell11.appendChild(element11);
			
			
	var element12 = document.createElement("input");
	element12.type = 'hidden';
	element12.name = 'teacher_exp_details_'+rowCount+'[]';//Name of table 
	element12.id = rid+13;
	var users = <?php echo json_encode($Sr_No2); ?>;
	if(rowCount<=users.length){
		element12.setAttribute("value", users[i]);
	}
	else{
	element12.setAttribute("value", "a");
	}
	cell11.appendChild(element12);


		rid=rid+13;
		}	
		
		
		//function to add rows in Industry details	
	function addrow8(tableID,i) {
          var table = document.getElementById(tableID);
		  var rowCount = table.rows.length;
		  var row = table.insertRow(rowCount);
		  
		  var cell0 = row.insertCell(0); 
			var element0 = document.createElement('input');                //checkbox
			element0.type = 'checkbox';
			element0.name = 'industry_exp_details_'+rowCount+'[]';
			element0.id =t9id+1;
			element0.style.cssText = "text-align:center";
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)
			var element1 = document.createElement('label');                 // label for numbering
			cell1.style.cssText = "text-align:center";
			element1.id = t9id+2;
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);
			var element2 = document.createElement('input');                 //text field for name       
			element2.type = 'text';
			element2.id=t9id+3;
			element2.name='industry_exp_details_'+rowCount+'[]';
			element2.placeholder='Organization Name';
			var users = <?php echo json_encode($Organization_name1); ?>; 
			if((rowCount)<=users.length){
				element2.value = users[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check9(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);
			var element3 = document.createElement('input');                  //text field for aurthor
			element3.type='text';
			element3.id=t9id+4;
			element3.name='industry_exp_details_'+rowCount+'[]';
			element3.placeholder='Desgination';
			var users = <?php echo json_encode($Designation1); ?>;
			if((rowCount)<=users.length){
				element3.value = users[i];
			}
			else{
				element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			cell3.appendChild(element3);
			
			var cell4 = row.insertCell(4);
			var element4 = document.createElement('input');                 //text field for year
			element4.type = 'Date';
			element4.id=t9id+5;
			element4.name='industry_exp_details_'+rowCount+'[]';
			element4.placeholder='dd/mm/yyyy';
			var users = <?php echo json_encode($Date_of_joining1); ?>;
			if((rowCount)<=users.length){
				element4.value = users[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);

			var cell5 = row.insertCell(5);
			var element5 = document.createElement('input');                 //text field for year
			element5.type = 'Date';
			element5.id=t9id+6;
			element5.name='industry_exp_details_'+rowCount+'[]';
			element5.placeholder='dd/mm/yyyy';
			var users = <?php echo json_encode($Date_of_working1); ?>;
			if((rowCount)<=users.length){
				element5.value = users[i];
			}
			else{
				element5.value = "";
				element5.required=true;
				element5.disabled=true;
			}
			cell5.appendChild(element5);

			var cell6 = row.insertCell(6);
			var element6 = document.createElement('input');                 //text field for Project Title       
			element6.type = 'text';
			element6.id=t9id+7;
			element6.name='industry_exp_details_'+rowCount+'[]';
			element6.placeholder='industry exp details_ in Years';
			element6.style.cssText="width:100%";
			var users = <?php echo json_encode($Industry_exp); ?>;
			//console.log(users);
			if((rowCount)<=users.length){
				element6.value = users[i];
			}
			else{
				element6.value = "";
				element6.required=true;
				element6.disabled=true;
			}
			//element11.setAttribute("onchange",'javascript:check1(this)');
			cell6.appendChild(element6);

			var element7 = document.createElement("input");
			element7.type = 'hidden';
			element7.name = 'industry_exp_details_'+rowCount+'[]';//Name of table 
			element7.id = t9id+8;
			var users = <?php echo json_encode($Sr_No3); ?>;
			if(rowCount<=users.length){
				element7.setAttribute("value", users[i]);
			}
			else{
			element7.setAttribute("value", "a");
			}
			cell6.appendChild(element7);

			
			t9id=t9id+8;					
			
		}	
		
		//function to add rows in Research details
		
		function addrow9(tableID,i) {
          var table = document.getElementById(tableID);
		  var rowCount = table.rows.length;
		  var row = table.insertRow(rowCount);
		  
		  var cell0 = row.insertCell(0); 
			var element0 = document.createElement('input');                //checkbox
			element0.type = 'checkbox';
			element0.name = 'research_exp_details_'+rowCount+'[]';
			element0.id =t10id+1;
			element0.style.cssText = "text-align:center";
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)
			var element1 = document.createElement('label');                 // label for numbering
			cell1.style.cssText = "text-align:center";
			element1.id = t10id+2;
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);

			var cell2 = row.insertCell(2);
			var element2 = document.createElement('input');                 //text field for name       
			element2.type = 'text';
			element2.id=t10id+3;
			element2.name='research_exp_details_'+rowCount+'[]';
			element2.placeholder='Organization Name';
			var users = <?php echo json_encode($Organization_name2); ?>; 
			if((rowCount)<=users.length){
				element2.value = users[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check9(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);
			var element3 = document.createElement('input');                  //text field for aurthor
			element3.type='text';
			element3.id=t10id+4;
			element3.name='research_exp_details_'+rowCount+'[]';
			element3.placeholder='Desgination';
			var users = <?php echo json_encode($Designation2); ?>;
			if((rowCount)<=users.length){
				element3.value = users[i];
			}
			else{
				//element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			cell3.appendChild(element3);

			var cell4 = row.insertCell(4);
			var element4 = document.createElement('input');                 //text field for year
			element4.type = 'Date';
			element4.id=t10id+5;
			element4.name='research_exp_details_'+rowCount+'[]';
			element4.placeholder='dd/mm/yyyy';
			var users = <?php echo json_encode($Date_of_joining2); ?>;
			if((rowCount)<=users.length){
				element4.value = users[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);

			var cell5 = row.insertCell(5);
			var element5 = document.createElement('input');                 //text field for year
			element5.type = 'Date';
			element5.id=t10id+6;
			element5.name='research_exp_details_'+rowCount+'[]';
			element5.placeholder='dd/mm/yyyy';
			var users = <?php echo json_encode($Date_of_working2); ?>;
			if((rowCount)<=users.length){
				element5.value = users[i];
			}
			else{
				element5.value = "";
				element5.required=true;
				element5.disabled=true;
			}
			cell5.appendChild(element5);

			var cell6 = row.insertCell(6);
			var element6 = document.createElement('input');                 //text field for Project Title       
			element6.type = 'text';
			element6.id=t10id+7;
			element6.name='research_exp_details_'+rowCount+'[]';
			element6.placeholder='Research exp details_ in Years';
			element6.style.cssText="width:100%";
			var users = <?php echo json_encode($Research_exp); ?>;
			//console.log(users);
			if((rowCount)<=users.length){
				element6.value = users[i];
			}
			else{
				element6.value = "";
				element6.required=true;
				element6.disabled=true;
			}
			//element11.setAttribute("onchange",'javascript:check1(this)');
			cell6.appendChild(element6);

			
			var element7 = document.createElement("input");
			element7.type = 'hidden';
			element7.name = 'research_exp_details_'+rowCount+'[]';//Name of table 
			element7.id = t10id+8;
			var users = <?php echo json_encode($Sr_No4); ?>;
			if(rowCount<=users.length){
				element7.setAttribute("value", users[i]);
			}
			else{
				element7.setAttribute("value", "a");
			}
			cell6.appendChild(element7);

			t10id=t10id+8;	
			
		}
		
		
		//Function to add rows in table - SUBJECT TAUGHT
	function addrow2(tableID,i) {
          
			var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell0 = row.insertCell(0); 
			var element0 = document.createElement('input');                //checkbox
			element0.type = 'checkbox';
			element0.name = 'subs_taught_'+rowCount+'[]';
			element0.id =t3id+1;
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)
			var element1 = document.createElement('label');                 // label for numbering
			element1.id = t3id+2;
			cell1.innerHTML = rowCount;
			cell1.style.cssText = "text-align:center";
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);
			var element2 = document.createElement('input');                 //text field for name       
			element2.type = 'text';
			element2.id=t3id+3;
			element2.name='subs_taught_'+rowCount+'[]';
			element2.placeholder='Type of Graduation';
			var users = <?php echo json_encode($Type_of_graduation); ?>;
			if((rowCount)<=users.length){
				element2.value = users[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check2(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);
			var element3 = document.createElement('input'); //text field for aurthor
			element3.id=t3id+4;
			element3.name='subs_taught_'+rowCount+'[]';
			element3.placeholder='Subject Taught';
			var users2 = <?php echo json_encode($Subject_taught); ?>;
			//console.log(users2);
			if((rowCount)<=users2.length){
				element3.value = users2[i];
			}
			else{
				element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			cell3.appendChild(element3);
			
			var cell4 = row.insertCell(4);
			var element4 = document.createElement('input');                 //text field for publisher  
			element4.type = 'text';
			element4.id=t3id+5;
			element4.name='subs_taught_'+rowCount+'[]';
			element4.placeholder='FH17/SH17';
			var users2 = <?php echo json_encode($Period_Year); ?>;
			//console.log(users2);
			if((rowCount)<=users2.length){
				element4.value = users2[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);
			
			var cell5 = row.insertCell(5);
			var element5 = document.createElement('input');                 //text field for publisher  
			element5.type = 'text';
			element5.id=t3id+6;
			element5.name='subs_taught_'+rowCount+'[]';
			element5.placeholder='Subject Experience';
			var users2 = <?php echo json_encode($sub_exp); ?>;
			//console.log(users2);
			if((rowCount)<=users2.length){
				element5.value = users2[i];
			}
			else{
				element5.value = "";
				element5.required=true;
				element5.disabled=true;
			}
			cell5.appendChild(element5);
						
			var cell6 = row.insertCell(6);
			var element6 = document.createElement('select');                 //text field for publisher  
			element6.id=t3id+7;
			element6.name='subs_taught_'+rowCount+'[]';
			element6.style.cssText = "width:100%";
			var visitor = <?php echo json_encode($Syllabus); ?>;
			if((rowCount)>visitor.length){
				var option0 = document.createElement("option");              //option none  
				option0.innerHTML = "None";
				option0.value = "";
				option0.disabled=true;
	        	option0.selected=true;
		    	element6.appendChild(option0);
		    	element6.required=true;
		    	element6.disabled=true;
			}
			//element6.required=true;
			//element6.disabled=true;
			
			//  var option0 = document.createElement("option");              //option none  
			// option0.innerHTML = "None";
			// option0.value = "";
			//option0.disabled=true;
			//
	        //option0.selected=true;

		    // element6.appendChild(option0);
			
			var option1 = document.createElement("option");
			option1.innerHTML="Old";
			option1.value="Old";
			if((rowCount)<=visitor.length && option1.value == visitor[i]){
				 option1.selected=true;
			}
			else{
				option1.selected=false;
			}
			element6.appendChild(option1);

			var option2 = document.createElement("option");
			option2.innerHTML="Revised";
			option2.value="Revised";
			var visitor = <?php echo json_encode($Syllabus); ?>;
			if((rowCount)<=visitor.length && option2.value == visitor[i]){
				 option2.selected=true;
			}
			else{
				option2.selected=false;
			}
			element6.appendChild(option2);
			cell6.appendChild(element6);
			
		var element7 = document.createElement("input");
			element7.type = 'hidden';
			element7.name = 'subs_taught_'+rowCount+'[]';//Name of table 
			element7.id = t4id+8;
			var users = <?php echo json_encode($Sr_No5); ?>;
			console.log(users);
			if(rowCount<=users.length){
				element7.setAttribute("value", users[i]);
			}
			else{
			element7.setAttribute("value", "a");
			}
			cell6.appendChild(element7);	

			
			
		t3id=t3id+8;
		}	
	
//Function to add rows in table - PROFESSIONAL MEMBERSHIP DETAILS	
		function addrow3(tableID,i) {
          
			var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell0 = row.insertCell(0); 
			var element0 = document.createElement('input');                //checkbox
			element0.type = 'checkbox';
			element0.name = 'prof_memship_'+rowCount+'[]';
			element0.id =t4id+1;
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)
			var element1 = document.createElement('label');                 // label for numbering
			element1.id = t4id+2;
			cell1.style.cssText = "text-align:center";
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);
			var element2 = document.createElement('input');                 //text field for name       
			element2.type = 'text';
			element2.id=t4id+3;
			element2.name='prof_memship_'+rowCount+'[]';
			element2.placeholder='Membership Category';
			var users2 = <?php echo json_encode($Membership_category); ?>;
			// //console.log("hi"+users2);
			if((rowCount)<=users2.length){
				element2.value = users2[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check3(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);
			var element3 = document.createElement('input'); //text field for aurthor
			element3.id=t4id+4;
			element3.name='prof_memship_'+rowCount+'[]';
			element3.placeholder='Membership Number';
			var users2 = <?php echo json_encode($Membership_no); ?>;
			// //console.log(users2);
			if((rowCount)<=users2.length){
				element3.value = users2[i];
			}
			else{
				element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			cell3.appendChild(element3);
			
			var cell4 = row.insertCell(4);
			var element4 = document.createElement('input');                 //text field for publisher  
			element4.type = 'text';
			element4.id=t4id+5;
			element4.name='prof_memship_'+rowCount+'[]';
			element4.placeholder='Body Of organization';
			var users2 = <?php echo json_encode($Body_of_organization); ?>;
			// //console.log(users2);
			if((rowCount)<=users2.length){
				element4.value = users2[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);

			var element5 = document.createElement("input");
			element5.type = 'hidden';
			element5.name = 'prof_memship_'+rowCount+'[]';//Name of table 
			element5.id = t4id+6;
			var users = <?php echo json_encode($Sr_No6); ?>;
			if(rowCount<=users.length){
				element5.setAttribute("value", users[i]);
			}
			else{
			element5.setAttribute("value", "a");
			}
			cell4.appendChild(element5);

	
			
		t4id=t4id+6;
		}	
//Function to add rows in table - INTERACTION WITH OUTSIDE WORLD
		function addrow4(tableID,i) {
          
			var table = document.getElementById(tableID);   
			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell0 = row.insertCell(0);                              //checkbox
			var element0 = document.createElement('input');
			element0.type = 'checkbox';
			element0.name = 'interact_outside_'+rowCount+'[]';
			element0.id =t5id+1;
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)                                 //label for numbering  
			var element1 = document.createElement('label');
			cell1.style.cssText = "text-align:center";
			element1.id = t5id+2;
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);                              //text field for paper title
			var element2 = document.createElement('input');
			element2.type = 'text';
			element2.id=t5id+3;
			element2.name='interact_outside_'+rowCount+'[]';
			element2.placeholder='Interaction Type';
			var users2 = <?php echo json_encode($Interaction_type); ?>;
			////console.log(users2);
			if((rowCount)<=users2.length){
				element2.value = users2[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check4(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);                              //text field for paper title
			var element3 = document.createElement('input');
			element3.type = 'text';
			element3.id=t5id+4;
			element3.name='interact_outside_'+rowCount+'[]';
			element3.placeholder='Organization';
			var users2 = <?php echo json_encode($Organization); ?>;
			////console.log(users2);
			if((rowCount)<=users2.length){
				element3.value = users2[i];
			}
			else{
				element3.value = "";
				element3.required="true";
				element3.disabled="true";
			}
			cell3.appendChild(element3);

			
			var cell4 = row.insertCell(4);          
			var element4 = document.createElement('input');               //date
			element4.type = 'date';
			element4.name='interact_outside_'+rowCount+'[]';
			element4.id=t5id+5;
			element4.placeholder='dd/mm/yyyy';
			var users2 = <?php echo json_encode($Date); ?>;
			////console.log(users2);
			if((rowCount)<=users2.length){
				element4.value = users2[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);

			var element5 = document.createElement("input");
			element5.type = 'hidden';
			element5.name = 'interact_outside_'+rowCount+'[]';//Name of table 
			element5.id = t5id+6;
			var users = <?php echo json_encode($Sr_No7); ?>;
			if(rowCount<=users.length){
				element5.setAttribute("value", users[i]);
			}
			else{
			element5.setAttribute("value", "a");
			}
			cell4.appendChild(element5);

		t5id=t5id+6;   
		}
//Function to add rows in table - TRAINING COURSES/ SEMINAR/ WORKSHOP/ CONFERENCE ATTENDED		
function addrow5(tableID,i) {
          
			var table = document.getElementById(tableID);   
			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell0 = row.insertCell(0);                              //checkbox
			var element0 = document.createElement('input');
			element0.type = 'checkbox';
			element0.name = 'train_conf_'+rowCount+'[]';
			element0.id =t6id+1;
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)                                 //label for numbering  
			var element1 = document.createElement('label');
			element1.id = t6id+2;
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);                              //text field for paper title
			var element2 = document.createElement('input');
			element2.type = 'text';
			element2.id=t6id+3;
			element2.name= 'train_conf_'+rowCount+'[]';
			element2.placeholder='Course Name';
			var users2 = <?php echo json_encode($course_name); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element2.value = users2[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check5(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);        
			var element3=document.createElement('input');
			element3.type='text';
			element3.name =  'train_conf_'+rowCount+'[]';
			element3.id=t6id+4;
			element3.placeholder='Name of Organizing Institute';
			var users2 = <?php echo json_encode($organization_name2); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element3.value = users2[i];
			}
			else{
				element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			cell3.appendChild(element3);
			
			var cell4 = row.insertCell(4);          
			var element4 = document.createElement('input');               //date
			element4.type = 'date';
			element4.name =  'train_conf_'+rowCount+'[]';
			element4.id=t6id+5;
			element4.placeholder='dd/mm/yyyy';
			var users2 = <?php echo json_encode($start_date); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element4.value = users2[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);
		
			var cell5 = row.insertCell(5);          	
			var element5 = document.createElement('input'); //date
			element5.type = 'date';
			element5.name = 'train_conf_'+rowCount+'[]';
			element5.id=t6id+6;
			element5.placeholder='dd/mm/yyyy';
			var users2 = <?php echo json_encode($end_date); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element5.value = users2[i];
			}
			else{
				element5.value = "";
				element5.required=true;
				element5.disabled=true;
			}
			cell5.appendChild(element5);	

			// var cell6 = row.insertCell(6);
			// var element6 = document.createElement('input');               //text field for impact
			// element6.type = 'text';
			// element6.id=t6id+7;
			// element6.name= 'train_conf_'+rowCount+'[]';
			// element6.placeholder='Total Days';
			// element6.required=true;
			// //element6.disabled=true;
			// cell6.appendChild(element6);
			
			var element6 = document.createElement("input");
			element6.type = 'hidden';
			element6.name = 'train_conf_'+rowCount+'[]';//Name of table 
			element6.id = t6id+7;
			var users = <?php echo json_encode($Sr_No8); ?>;
			//console.log(users);
			if(rowCount<=users.length){
				element6.setAttribute("value", users[i]);
			}
			else{
			element6.setAttribute("value", "a");
			}
			cell5.appendChild(element6);

		  t6id=t6id+7;   

		}

//Function to add rows in table - TRAINING COURSES/ SEMINAR/ WORKSHOP/ CONFERENCE ORGANIZED	
	  function addrow6(tableID,i) {
          
			var table = document.getElementById(tableID);   
			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell0 = row.insertCell(0);                              //checkbox
			var element0 = document.createElement('input');
			element0.type = 'checkbox';
			element0.name = 'organization_'+rowCount+'[]';
			element0.id =t7id+1;
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)                                 //label for numbering  
			var element1 = document.createElement('label');
			cell1.style.cssText = "text-align:center";
			element1.id = t7id+2;
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);                              //text field for paper title
			var element2 = document.createElement('input');
			element2.type = 'text';
			element2.id=t7id+3;
			element2.name='organization_'+rowCount+'[]';
			element2.placeholder='Course Name';
			var users2 = <?php echo json_encode($course_name2); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element2.value = users2[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check2(this)');
			}
			cell2.appendChild(element2);

			var cell3 = row.insertCell(3);        
			var element3=document.createElement('input');
			element3.type = 'text';
			element3.name = 'organization_'+rowCount+'[]';
			element3.id=t7id+4;
			element3.placeholder='Responsibility Handled';
			var users2 = <?php echo json_encode($responsibility); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element3.value = users2[i];
			}
			else{
				element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			cell3.appendChild(element3);
			
			var cell4 = row.insertCell(4);          
			var element4 = document.createElement('input');               //date
			element4.type = 'date';
			element4.name = 'organization_'+rowCount+'[]';
			element4.id=t7id+5;
			element4.placeholder='dd/mm/yyyy';
			var users2 = <?php echo json_encode($course_duration); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element4.value = users2[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			cell4.appendChild(element4);

			var element5 = document.createElement("input");
			element5.type = 'hidden';
			element5.name = 'organization_'+rowCount+'[]';//Name of table 
			element5.id = t7id+6;
			var users = <?php echo json_encode($Sr_No9); ?>;
			//console.log("t"+users);
			if(rowCount<=users.length){
				element5.setAttribute("value", users[i]);
			}
			else{
			element5.setAttribute("value", "a");
			}
			cell4.appendChild(element5);

			
		  t7id=t7id+6;   
		}
		

  function addrow7(tableID,i) {
          
			var table = document.getElementById(tableID);   
			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell0 = row.insertCell(0);                              //checkbox
			var element0 = document.createElement('input');
			element0.type = 'checkbox';
			element0.name = 'projects_guided_'+rowCount+'[]';
			element0.id =t8id+1;
			cell0.appendChild(element0);
			
			var cell1 =row.insertCell(1)                                 //label for numbering  
			var element1 = document.createElement('label');
			element1.id =t8id+2;
			cell1.innerHTML = rowCount;
			cell1.appendChild(element1);
			
			var cell2 = row.insertCell(2);                              //text field for paper title
			var element2 = document.createElement('input');
			element2.type = 'text';
			element2.id=t8id+3;
			element2.name= 'projects_guided_'+rowCount+'[]';
			element2.placeholder='Project Title';
			var users2 = <?php echo json_encode($project_title); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element2.value = users2[i];
			}
			else{
				element2.value = "";
				element2.setAttribute("onchange",'javascript:check5(this)');
			}
			
			cell2.appendChild(element2);


			var cell3 = row.insertCell(3);        
			var element3=document.createElement('input');
			element3.type = 'text';
			element3.id=t8id+4;
			element3.name= 'projects_guided_'+rowCount+'[]';
			element3.placeholder='Guide Name';
			var users2 = <?php echo json_encode($guide_name); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element3.value = users2[i];
			}
			else{
				element3.value = "";
				element3.required=true;
				element3.disabled=true;
			}
			
			cell3.appendChild(element3);
			
			var cell4 = row.insertCell(4);          
			var element4 = document.createElement('input');               //date
			element4.type='text';
			element4.name = 'projects_guided_'+rowCount+'[]';
			element4.id=t8id+5;
			element4.placeholder='Members';
			var users2 = <?php echo json_encode($group_members); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element4.value = users2[i];
			}
			else{
				element4.value = "";
				element4.required=true;
				element4.disabled=true;
			}
			
			cell4.appendChild(element4);
		
			var cell5 = row.insertCell(5);          	
			var element5 = document.createElement('input'); //date
			element5.type = 'text';
			element5.id=t8id+6;
			element5.name= 'projects_guided_'+rowCount+'[]';
			element5.placeholder='Department';
			var users2 = <?php echo json_encode($dept); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element5.value = users2[i];
			}
			else{
				element5.value = "";
				element5.required=true;
				element5.disabled=true;
			}
			
			cell5.appendChild(element5);	

			var cell6 = row.insertCell(6);
			var element6 = document.createElement('input');               //text field for impact
			element6.type = 'date';
			element6.id=t8id+7;
			element6.name= 'projects_guided_'+rowCount+'[]';
			element6.placeholder='';
			var users2 = <?php echo json_encode($year); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element6.value = users2[i];
			}
			else{
				element6.value = "";
				element6.required=true;
				element6.disabled=true;
			}
			
			cell6.appendChild(element6);
			

			var cell7 = row.insertCell(7);
			var element7 = document.createElement('select');               //text field for impact
			element7.name = 'projects_guided_'+rowCount+'[]';
			element7.id=t8id+8;
			var visitor = <?php echo json_encode($student_cat); ?>;
			if((rowCount)>visitor.length){
				var option1 = document.createElement("option");              //option none  
				option1.innerHTML = "None";
				option1.value = "";
				option1.disabled=true;
	        	option1.selected=true;
	        	element7.required=true;
	        	element7.disabled=true;
			}
			//element7.required=true;
			//element7.disabled=true;
					
			// var option1 = document.createElement("option");              //option none  
			// option1.innerHTML = "None";
			// option1.value = "";
			// //option1.disabled=true;
	  //       option1.selected=true;
			
			var option2 = document.createElement("option");              //option none  
			option2.innerHTML = "U.G.";
			option2.value = "U.G.";
			if((rowCount)<=visitor.length && option2.value == visitor[i]){
				 option2.selected=true;
			}
			else{
				option2.selected=false;
			}
			
			var option3 = document.createElement("option");              //option none  
			option3.innerHTML = "P.G.";
			option3.value = "P.G.";
			var visitor = <?php echo json_encode($student_cat); ?>;
			if((rowCount)<=visitor.length && option3.value == visitor[i]){
				 option3.selected=true;
			}
			else{
				option3.selected=false;
			}
			
			var option4 = document.createElement("option");              //option none  
			option4.innerHTML = "Ph.G.";
			option4.value = "Ph.G.";
			var visitor = <?php echo json_encode($student_cat); ?>;
			if((rowCount)<=visitor.length && option4.value == visitor[i]){
				 option4.selected=true;
			}
			else{
				option4.selected=false;
			}
			
			
			// element7.appendChild(option1);
			element7.appendChild(option2);
			element7.appendChild(option3);
			element7.appendChild(option4);
			
			cell7.appendChild(element7);
			
			var cell8 = row.insertCell(8);          	
			var element8 = document.createElement('input'); //date
			element8.type = 'text';
			element8.id=t8id+9;
			element8.name= 'projects_guided_'+rowCount+'[]';
			element8.placeholder='Remark';
			var users2 = <?php echo json_encode($remark); ?>;
			// //console.log("rashmi"+users2);
			if((rowCount)<=users2.length){
				element8.value = users2[i];
			}
			else{
				element8.value = "";
				element8.required=true;
				element8.disabled=true;
			}
			
			cell8.appendChild(element8);	

			var element9 = document.createElement("input");
			element9.type = 'hidden';
			element9.name = 'projects_guided_'+rowCount+'[]';//Name of table 
			element9.id = t8id+10;
			var users = <?php echo json_encode($Sr_No10); ?>;
			if(rowCount<=users.length){
				element9.setAttribute("value", users[i]);
			}
			else{
			element9.setAttribute("value", "a");
			}
			cell8.appendChild(element9);


			
		  t8id=t8id+10;   

		}
		
		//function to delete row when checkbox is checked 
		function delrow(tableID,i) {
			try {
			var table = document.getElementById(tableID);//retrieving table from id
			var rowCount = table.rows.length;//no rows in table
			var rowc = rowCount;//for comparison
			var count = 0;//counter to check
			alert(rowc);
			var c = <?php echo json_encode($qualification); ?>;
			var sr1 = <?php echo json_encode($Sr_No1); ?>;
			var c2 = <?php echo json_encode($Organization_name); ?>;
			var sr2 = <?php echo json_encode($Sr_No2); ?>;
			var c3 = <?php echo json_encode($Organization_name1); ?>;
			var sr3 = <?php echo json_encode($Sr_No3); ?>;
			var c4 = <?php echo json_encode($Organization_name2); ?>;
			var sr4 = <?php echo json_encode($Sr_No4); ?>;
			var c5 = <?php echo json_encode($Type_of_graduation); ?>;
			var sr5 = <?php echo json_encode($Sr_No5); ?>;
			var c6 = <?php echo json_encode($Membership_category); ?>;
			var sr6 = <?php echo json_encode($Sr_No6); ?>;
			var c7 = <?php echo json_encode($Interaction_type); ?>;
			var sr7 = <?php echo json_encode($Sr_No7); ?>;
			var c8 = <?php echo json_encode($course_name); ?>;
			var sr8 = <?php echo json_encode($Sr_No8); ?>;
			var c9 = <?php echo json_encode($course_name2); ?>;
			var sr9 = <?php echo json_encode($Sr_No9); ?>;
			var c10 = <?php echo json_encode($project_title); ?>;
			var sr10 = <?php echo json_encode($Sr_No10); ?>;
			
			
			//alert(tableID);
			for(var i=1; i<rowCount; i++) {
				var row = table.rows[i];
				var chkbox = row.cells[0].childNodes[0];
				//condition to delete row if checked
				if(null != chkbox && true == chkbox.checked) {
					table.deleteRow(i);
					rowCount--;
					i--;
					if(tableID=='table2-1'){
						if((rowc-1)<=c.length){
							window.location.href = "tast.php?sr=" + (sr1[i])+"&tableID="+"qualification_details";
						}
					} 
					if(tableID=='table2-2'){
						if((rowc-1)<=c2.length){
							window.location.href = "tast.php?sr=" + (sr2[i])+"&tableID="+"teacher_experience_details";
						}
					}
					if(tableID=='table2-9'){
						if((rowc-1)<=c3.length){
							window.location.href = "tast.php?sr=" + (sr3[i])+"&tableID="+"industry_experience_details";
						}
					}if(tableID=='table2-10'){
						if((rowc-1)<=c4.length){
							window.location.href = "tast.php?sr=" + (sr4[i])+"&tableID="+"research_experience_details";
						}
					}if(tableID=='table2-3'){
						if((rowc-1)<=c5.length){
							window.location.href = "tast.php?sr=" + (sr5[i])+"&tableID="+"subject_taught";
						}
					}if(tableID=='table2-4'){
						if((rowc-1)<=c6.length){
							window.location.href = "tast.php?sr=" + (sr6[i])+"&tableID="+"professional_membership";
						}
					}if(tableID=='table2-5'){
						if((rowc-1)<=c7.length){
							window.location.href = "tast.php?sr=" + (sr7[i])+"&tableID="+"interaction_with_outside_world";
						}
					}if(tableID=='table2-6'){
						if((rowc-1)<=c8.length){
							window.location.href = "tast.php?sr=" + (sr8[i])+"&tableID="+"training_courses_attended";
						}
					}if(tableID=='table2-7'){
						if((rowc-1)<=c9.length){
							window.location.href = "tast.php?sr=" + (sr9[i])+"&tableID="+"training_courses_organize";
						}
					}if(tableID=='table2-8'){
						if((rowc-1)<=c10.length){
							window.location.href = "tast.php?sr=" + (sr10[i])+"&tableID="+"project_guided";
						}
					} 
					}
				else{
					//increment counter if checkbox not checked
					count+=1;
				}
			}
			//if counter is equal to no. of rows-1 then display msg
			if(count == rowc-1){
				alert("Select row to delete");
			}
			//else rearrange the numbering in table
			else{
			rearrange(tableID);
			}
			}catch(e) {
				alert(e);
			}
		}
		
		//function to rearrange numbering in table if row is deleted
		function rearrange(tableID) {
			alert("Selected row has been deleted");
			var table = document.getElementById(tableID);
			for (var i = 1; i < table.rows.length; i++) {
				var row = table.rows[i];
				row.cells[1].innerHTML=i;
			}
		}
		
		/*function check_faculty_type(){
			var faculty_type = '<?php echo($_SESSION['faculty_type']); ?>'
			var t = document.getElementById("tab1");
			var t1 = document.getElementById("tab2");
			if(faculty_type == "nonteaching"){
				t.style.cssText='display:none';
				t1.style.cssText='display:none';
			}
			else{
				t.style.cssText='display:visible';
				t1.style.cssText='display:visible';
				}
		}*/
</script>
<link href="ab.css" rel="stylesheet">
</head>
<body>
<!-- <div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
 -->

<br>
<center>

<form id="form2-2" action="edit2-2.php" method="POST" enctype="multipart/form-data">	
<div id="tab0">
<h2 style="text-align: center">Qualification Details</h2>
<table align='center' border='1' id='table2-1' name="qualific_details" style="table-layout: fixed; width:95%">
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
 <th>Qualification</th>
 <th>Branch</th>
 <th>Specialization</th>
 <th>University</th>
 <th>Percentage</th>
 <th>CGPA</th>
 <th>Class Obtained</th>
 <th>Passing Year</th>
<!--  <th>Attach Proof</th> -->
 </tr>
</table>
<p class="inline" style="text-align: center">
<input id='b1' style='height:25px; width:100px' type='button' value="Add" onclick='addrow("table2-1",i1)' />
<input id='b3' style='height:25px; width:100px' type='button' value="Delete" onclick='delrow("table2-1",i1)' />
<br/><br/><br/>
</p>
</div>

<div id="">
<h2 style="text-align: center;">Teaching Experience Details</h2>
<table align='center' border='1' id='table2-2' style="table-layout: fixed; width:95%">
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
 <th>Organization Name</th>

<th>Designation</th>
<th>Date of joining</th>
<th>Last Date of working</th>
<th>Current pay scale</th>

<th>Grade pay</th>
<th>Nature of appointment</th>
<th>USSC Approved Date</th>
<th>USSC Approved Reference Number</th>
<th>Teaching Experience </th>
<!-- <th >Proof</th> -->
 
</tr>
</table>
<p class="inline" style="text-align: center">
<input id='b2' style='height:25px;width:100px' type='button' value="Add" onclick='addrow1("table2-2",i2)' />
<input id='b4' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2-2",i2)' />
<br /><br />
</p>
</div>
<!--<center>
<label>Area of Interest:</label>
<input type='text' name='aoi'  required />
</center>-->





<div id="tab3">
<h2 style="text-align: center;">Industry Experience Details </h2>
<table align='center' border='1' id='table2-9' style="table-layout: fixed; width:95%">
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
 <th>Organization Name</th>

<th>Designation</th>
<th>Date of joining</th>
<th>Last Date of working</th>
<th>Industrial Experience </th>
<!-- <th>Attach Proof</th> -->
</tr>
</table>
<p class="inline" style="text-align: center">
<input id='b1' style='height:25px;width:100px' type='button' value="Add" onclick='addrow8("table2-9",i3)' />
<input id='b3' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2-9",i3)' />
<br/><br/><br/>
</p>
</div>


<div id="tab3">
<h2 style="text-align: center;">Research Experience Details </h2>
<table align='center' border='1' id='table2-10' style="table-layout: fixed; width:95%">
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
<th>Organization Name</th>

<th>Designation</th>
<th>Date of joining</th>
<th>Last Date of working</th>
<th>Research Experience </th>
</tr>
</table>
<p class="inline" style="text-align: center">
<input id='b1' style='height:25px;width:100px' type='button' value="Add" onclick='addrow9("table2-10",i4)' />
<input id='b3' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2-10",i4)' />
<br/><br/><br/>
</p>
</div>







<!--jaya-->
<div id="tab1">
<h2 style="text-align: center;">Subjects Taught</h2>
<table align='center' border='1' id='table2-3' style="table-layout: fixed; width:95%">
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
 <th>Type Of Graduation</th>
 <th>Subject Taught</th>
 <th>Period / Year</th>
 <th>Subject Experience</th>
 <th>Syllabus Revised / Old</th>
 
</tr>
</table>

<p class="inline" style="text-align: center">
<input id='b2' style='height:25px;width:100px' type='button' value="Add" onclick='addrow2("table2-3",i5)' />
<input id='b4' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2-3",i5)' />
<br/><br/><br>
</p>
</div>

<div id="tab2">
<h2 style="text-align: center">Professional Membership Details</h2>
<table align='center' border='1' id='table2-4' style="table-layout: fixed; width:95%">
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
 <th>Membership Category</th>
 <th>Membership Number</th>
 <th>Body Of organization_</th>
</tr>
</table>

<p class="inline" style="text-align: center">
<input id='b1' style='height:25px;width:100px' type='button' value="Add" onclick='addrow3("table2-4",i6)' />
<input id='b3' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2-4",i6)' />
<br/><br/><br/>
</p>
</div>
<!--<center>
<label>Patent Recievd:</label>
<input type='text' name='patent' required />
</center>
-->
<div id="tab3">
<h2 style="text-align: center;">Interaction With Outside World </h2>
<table align='center' border='1' id='table2-5' style="table-layout: fixed; width:95%">
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
 <th>Interaction Type</th>
 <th>organization_</th>
 <th>Date</th>
</tr>
</table>
<p class="inline" style="text-align: center">
<input id='b1' style='height:25px;width:100px' type='button' value="Add" onclick='addrow4("table2-5",i7)' />
<input id='b3' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2-5",i7)' />
<br/><br/><br/>
</p>
</div>

<div id="tab4">
<h2 style="text-align: center;">Training Courses/ Seminar/ Workshop/ Conference<br/>ATTENDED</h2>
<table align='center' border='1' id='table2-6' style="table-layout: fixed; width:95%">
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
 <th style="width:20%">Course Name: </th>
 <th style="width:18%">Name Of the Organizing Institute</th>
 <th style="width:11%">Start Date</th>
 <th style="width:11%">End Date</th>
<!--  <th style="width:11%">Total Number of Days</th> -->
 <!-- <th>Proof/ Certificate</th>
 --></tr>
</table>
<p class="inline" style="text-align: center">
<input id='b2' style='height:25px;width:100px' type='button' value="Add" onclick='addrow5("table2-6",i8)' />
<input id='b4' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2-6",i8)' />
<br/><br/><br/>
</p>

<div id="tab5">
	<h2 style="text-align: center;">Training Courses/ Seminar/ Workshop/ Conference<br/>organized</h2>
<table align='center' border='1' id='table2-7' style="table-layout: fixed; width:95%">
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
 <th>Course Name: </th>
 <th>Responsibility Handled</th>
 <th>Course Duration</th>
 <!-- <th>Proof/ Certificate</th>
 --></tr>
</table>
<p class="inline" style="text-align: center">
<input id='b2' style='height:25px;width:100px' type='button' value="Add" onclick='addrow6("table2-7",i9)' />
<input id='b4' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2-7",i9)' />
<br/><br/><br/>
</p>
</div>

<div id="tab6">
<table align='center' border='1' id='table2-8' style="table-layout: fixed; width:95%">
<h2 style="text-align: center;">Project Guided</h2>
<tr>
 <th style="width:6%"></th>
 <th style="width:8%">Sr.No.</th>
 <th>Project Title</th>
 <th>Guide Name</th>
 <th>Group Members</th>
 <th>Department</th>
 <th>Year</th>
 <th>Student Category</th>
 <th>Remark</th>
</tr>
</table>
<p class="inline" style="text-align: center">
<input id='b2' style='height:25px;width:100px' type='button' value="Add" onclick='addrow7("table2-8",i10)' />
<input id='b4' style='height:25px;width:100px' type='button' value="Delete" onclick='delrow("table2-8",i10)' />
<br/><br/><br/>
</p>
</div>

<div align="center">
<input type="submit" name="submit" value="SUBMIT" style="width: 230px;margin-top: 15px;margin-bottom: 8px; height:40px;" >
</div>
</br></br>
</form>


<script>
	var users1 = <?php echo json_encode($qualification); ?>;
	////console.log(users);
	//alert(users);
	if (users1.length>0) {
		for(var i1=0;i1<users1.length;i1++){
		addrow("table2-1",i1);
	}
}
	else{
		addrow("table2-1",0);
	}
	var users2 = <?php echo json_encode($Organization_name); ?>;
	////console.log(users);
	if (users2.length>0) {
	for(var i2=0;i2<users2.length;i2++){
		addrow1("table2-2",i2);
	}
	}
	else{
		addrow1("table2-2",0);
	}
		var users3 = <?php echo json_encode($Organization_name1); ?>;
	////console.log(users);
	if (users3.length>0) {
	for(var i3=0;i3<users3.length;i3++){
		addrow8("table2-9",i3);
	}
}
	else{
		addrow8("table2-9",0);
	}
	var users4 = <?php echo json_encode($Organization_name2); ?>;
	////console.log(users);
	if (users4.length>0) {
	for(var i4=0;i4<users4.length;i4++){
		addrow9("table2-10",i4);
	}
}
	else{
		addrow9("table2-10",0);
	}
	var users5 = <?php echo json_encode($Type_of_graduation); ?>;
	////console.log(users);
	if (users5.length>0) {
	for(var i5=0;i5<users5.length;i5++){
		addrow2("table2-3",i5);
	}
}
	else{
		addrow2("table2-3",0);
	}
	var users6 = <?php echo json_encode($Membership_category); ?>;
	////console.log(users);
	if (users6.length>0) {
	for(var i6=0;i6<users6.length;i6++){
		addrow3("table2-4",i6);
	}
}
	else{
		addrow3("table2-4",0);
	}

	var users7 = <?php echo json_encode($Interaction_type); ?>;
	////console.log(users7);
	if (users7.length>0) {
	for(var i7=0;i7<users7.length;i7++){
		addrow4("table2-5",i7);
	}
}
	else{
		addrow4("table2-5",0);
	}

	var users8 = <?php echo json_encode($course_name); ?>;
	////console.log(users);
	if (users8.length>0) {
	for(var i8=0;i8<users8.length;i8++){
		addrow5("table2-6",i8);
	}
}
	else{
		addrow5("table2-6",0);
	}

	var users9 = <?php echo json_encode($course_name2); ?>;
	////console.log(users);
	if (users9.length>0) {
	for(var i9=0;i9<users9.length;i9++){
		addrow6("table2-7",i9);
	}
}
	else{
		addrow6("table2-7",0);
	}
	var users10 = <?php echo json_encode($project_title); ?>;
	////console.log(users);
	if (users10.length>0) {
	for(var i10=0;i10<users10.length;i10++){
		addrow7("table2-8",i10);
	}
}
	else{
		addrow7("table2-8",0);
	}
</script>




</html>