<?php 

session_start();
if(isset($_SESSION['eid']))
{
	session_destroy();
	header("Location: login.php");
}
else
{
	header("Location: home.php");
}

?>