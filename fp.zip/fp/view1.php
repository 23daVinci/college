<?php
include('account.php');
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
#records {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 63%;

}

#records td, #records th {
    border: 1px solid #A9A9A9;
    padding: 8px;
}

#records th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #DCDCDC;
    color: black;
    width: 30%;
}
#records td {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: white;
    color: black;
}

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}


hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 

body {
    font-family: "Lato", sans-serif;
    color:black;
}
	
</style>
</head>
<body>
<!-- <div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
   <br>
 -->   <div>
   	<h2 align="center">
   	PERSONAL INFORMATION</h2>
   </div>

<?php
//session_start();
//print_r($_SESSION);

$empid=$_SESSION['eid'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "SELECT * from faculty_personal_details where emp_id='$empid'";
$result = $conn->query($sql);

$sql1= "SELECT * from bank_account_details where emp_id='$empid'";
$result1 = $conn->query($sql1);

$sql2 = "SELECT * from staff_emp_details where emp_id='$empid'";
$result2 = $conn->query($sql2);

if ($result->num_rows > 0 && $result1->num_rows > 0 && $result2->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        //echo "Lastname: " . $row["last_name"]. " <br> Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";

        echo "<table id='records' align='center'>

<tr>

<th>Employee ID</th>

<td>". $result2->fetch_assoc()["college_emp_id"] ."</td>

</tr>

<tr>

<th>Last name</th>

<td>". $row['last_name'] ."</td>

</tr>


<tr>

<th>Middle name</th>

<td>". $row['middle_name'] ."</td>

</tr>

<tr>

<th>First name</th>

<td>". $row['first_name'] ."</td>

</tr>

<tr>

<th>Spouse name</th>

<td>". $row['spouse_name'] ."</td>

</tr>


<tr>

<th>Date of Birth</th>

<td>". $row['dob'] ."</td>

</tr>

<tr>

<th>Age</th>

<td>". $row['age'] ."</td>

</tr>

<tr>

<th>Gender</th>

<td>". $row['Gender'] ."</td>

</tr>

<tr>

<th>Marital status</th>

<td>". $row['marital_status'] ."</td>

</tr>

<tr>

<th>Mobile number</th>

<td>". $row['mobile_no'] ."</td>

</tr>

<tr>

<th>Residential number</th>

<td>". $row['residential_no'] ."</td>

</tr>

<tr>

<th>Email id</th>

<td>". $row['email'] ."</td>

</tr>

<tr>

<th>Alternate email id</th>

<td>". $row['alt_email'] ."</th>

</tr>

<tr>

<th>PAN number</th>

<td>". $row['pan_no'] ."</td>

</tr>

<tr>

<th>PF Number</th>

<td>". $row['pf_no'] ."</td>

</tr>

<tr>

<th>Permanent Address</th>

<td>". $row['permanent_address'] ."</td>

</tr>

<tr>

<th>Current Address</th>

<td>". $row['current_address'] ."</td>

</tr>

<tr>

<th>Mother's name</th>

<td>". $row['mothers_name'] ."</td>

</tr>

<tr>

<th>Father's name</th>

<td>". $row['fathers_name'] ."</td>

</tr>

<tr>

<th>Religion</th>

<td>". $row['religion'] ."</td>

</tr>

<tr>

<th>Category</th>

<td>". $row['category'] ."</td>

</tr>

<tr>

<th>Caste</th>

<td>". $row['caste'] ."</td>

</tr>

<tr>

<th>Nationality</th>

<td>". $row['nationality'] ."</td>

</tr>

<tr>

<th>Passport number</th>

<td>". $row['passport_no'] ."</td>

</tr>

<tr>

<th>Form 16</th>

<td>". $row['form_16'] ."</td>

</tr>";
} /*}
else {
    echo "0 results";
}

if ($result1->num_rows > 0) {
    // output data of each row*/
    while($row1 = $result1->fetch_assoc()) {
        echo "

<tr>

<th>Bank Name</th>

<td>". $row1['bank_name'] ."</td>

</tr>

<tr>

<th>Account no.</th>

<td>". $row1['acc_no'] ."</td>

</tr>

<tr>

<th>IFSC code</th>

<td>". $row1['IFSC_code'] ."</td>

</tr>

<tr>

<th>Branch</th>

<td>". $row1['branch'] ."</td>

</tr>


<tr>

<th>Bank account holder name</th>

<td>". $row1['bank_acc_holder_name'] ."</td>

</tr>
</table>";
} }
else {
    echo "<b>PERSONAL DETAILS NOT YET FILLED";
}


$conn->close();
?>

</body>
</html>