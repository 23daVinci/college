<?php

//session_start();
if(isset($_SESSION['eid']))
{
$empid=$_SESSION['eid'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "SELECT * from paper_publication where emp_id='$empid'";
$result = $conn->query($sql);
$sql2= "SELECT * from book_publication where emp_id='$empid'";
$result2 = $conn->query($sql2);
if ($result->num_rows > 0 && $result2->num_rows > 0) {
echo "Already Exists";
}
else{
	header("Location:stage5.php");
}
}
?>