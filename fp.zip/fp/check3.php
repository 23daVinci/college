<?php
include('account.php');
?>
<?php
//session_start();
$empid=$_SESSION['eid'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "SELECT * from other_responsibility where emp_id='$empid'";
$result = $conn->query($sql);

//print_r($data);
//echo "Select the responsibilities to be <b>DELETED</b>";
//$myArray = explode(',', $data);
//print_r($myArray);
if ($result->num_rows > 0) {

echo "<table id='records'>
<tr>

<th colspan='2'><center>Responsibilties Handled<center></th>
</tr>";
$result = $conn->query($sql);
    // output data of each row
    //$i = sizeof($myArray);
    while($row = $result->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        echo "<tr>";
        echo "<td><input type='checkbox' id ='check' name=".$row['responsibility']."/>";
  echo "<td>" . $row['responsibility'] . "</td>";

  echo "</tr>";
    }
    echo "</table>";
} else {
    header("Location:stage3.php");
}
$conn->close();
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
#records {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#records td, # th {
    border: 1px solid #ddd;
    padding: 8px;
}

#records tr:nth-child(even){background-color: #f2f2f2;}

#records tr:hover {background-color: #ddd;}

#records th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #DCDCDC;
    color: black;
}


#records td {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: white;
    color: black;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}


hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 

body {
    font-family: "Lato", sans-serif;
    color:black;
}
  
</style>
</head>
<body>
<!-- <div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
 -->   <br>

</body>
</html>


