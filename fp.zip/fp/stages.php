<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
<center><h1>HOME</h1></center>
</body>
</html>

<?php

session_start();
//print_r($_SESSION);

print_r($_SESSION['eid']);

?>

 
<br><br>
<a href="stage1.php" >stage 1</a><br><br>
<a href="stage2-1.php" >stage 2-1</a><br><br>
<a href="stage2-2.php" >stage 2-2</a><br><br>
<a href="stage3.php" >stage 3</a><br><br>
<a href="stage4.php" >stage 4</a><br><br>
<a href="stage5.php" >stage 5</a><br><br>

