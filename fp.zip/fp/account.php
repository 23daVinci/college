<?php
session_start();
if(!isset($_SESSION['eid']))
{
  header("Location: login.php");
}
?>

<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
	.navbar {
    overflow: hidden;
    background-color: #DCDCDC;
    font-family: Arial;
}

.dropdown-content a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: black;
    padding: 14px 16px;
    background-color: inherit;
    font: inherit;
    margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: 	#C0C0C0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 130px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}

</style>
</head>
<body>
<div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div>
   <div class="navbar">
  <div class="dropdown">
    <button class="dropbtn">Personal Information 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view1.php">View</a>
      <a href="check.php">Edit</a>
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Staff Employment Details-1 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view2.php">View</a>
      <a href="check2-1.php">Edit/Fill</a>
      
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Staff Employment Details-2 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view2-2.php">View</a>
      <a href="check2-21.php">Edit/Fill</a>
      
    </div>
  </div> 

  <div class="dropdown">
    <button class="dropbtn">Responsibilities Handled
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view3.php">View</a>
      <a href="edit3.php">Edit/Fill</a>
      
    </div>
  </div>
  <div class="dropdown">
    <button class="dropbtn">R&D Details 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view4.php">View</a>
      <a href="check4.php">Edit/Fill</a>
      
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Paper & Book Publication Details
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view5.php">View</a>
      <a href="check5.php">Edit/Fill</a>
      
    </div>
  </div>  
<!-- Add the below code to every page where you want to have a logout button -->
<!-- Logout Button Starts -->
  <div class="dropdown">
    <a href="logout.php"> 
      <button class="dropbtn">
        <b>LOGOUT</b>
      </button>
    </a>
  </div> 
<!-- Logout Button Ends -->

</div>
</body>
</html>
