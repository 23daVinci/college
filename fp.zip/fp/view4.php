<?php
include('account.php');
?>
<!doctype html>
<html>
<head>
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all" />
<style type="text/css">
#records {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#records td, th {
    border: 1px solid black;
    padding: 8px;
}

#records tr:nth-child(even){background-color: #f2f2f2;}

#records tr:hover {background-color: #ddd;}

#records th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #DCDCDC;
    color: black;
}


#records td {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: white;
    color: black;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: #111;
}


hr { 
    display: block;
    margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 1px;
} 

body {
    font-family: "Lato", sans-serif;
    color:black;
}
  
</style>
</head>
<body>
<!-- <div class="wrapper row1" align="center">
  <header id="header" class="hoc clear"> 
    <div >
      <p align="center" style="font-size:30px;font-family:sans-serif ; color:white; "><img src="images/demo/fcritlogo.png" style="width:150px; height:150px; background:none !important;border: none !important;"/>FR. C. RODRIGUES INSTITUTE OF TECHNOLOGY</a></p>
    </div>
   </header>
   </div> -->
   <br>
   <div>
    <h2 align="center">
  R&D DETAILS</h2>
   </div>


<?php
//session_start();
$empid=$_SESSION['eid'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql= "SELECT * from internal_fundedproject where emp_id='$empid'";
$result = $conn->query($sql);

$sql1= "SELECT * from external_fundedproject where emp_id='$empid'";
$result1 = $conn->query($sql1);


if ($result->num_rows > 0 || $result1->num_rows > 0) {
    // output data of each row
  echo "<br>INTERNAL FUNDED PROJECT<br>";
        echo "<table id='records'>
<tr>
 <th rowspan='2'>Project Title</th>
 <th colspan='2'>Investigator</th>
 <th rowspan='2'>Department</th>
 <th rowspan='2'>Year</th>
 <th rowspan='2'>Project Cost</th>
 <th rowspan='2'>Project Utility</th>
</tr>
<tr>
 <th>Staff Name</th>
 <th>Student Name</th>
</tr>";
    while($row = $result->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        

echo "<tr>";

  echo "<td>" . $row['Project_title'] . "</td>";

  echo "<td>" . $row['staff_name'] . "</td>";

  echo "<td>" . $row['student_name'] . "</td>";
  echo "<td>" . $row['department'] . "</td>";
  echo "<td>" . $row['year'] . "</td>";
  echo "<td>" . $row['project_cost'] . "</td>";
  echo "<td>" . $row['project_utility'] . "</td>";
  
  echo "</tr>";
    }
    echo "</table>";
/*} else {
    echo "0 results";
}


if ($result1->num_rows > 0) {
    // output data of each row*/
  echo "<br>EXTERNAL FUNDED PROJECT<br>";
        echo"<table id='records'>
<tr>
 <th rowspan='2'>Project Title</th>
 <th colspan='2'>Investigator</th>
 <th colspan='2'>Duration</th>
 <th rowspan='2'>Project Cost</th>
 <th rowspan='2'>Amount Recieved</th>
 <th rowspan='2'>Grant Type</th>
 <th rowspan='2'>Funding Body</th>
 <!--<th rowspan='2'>Year</th> -->
 <th rowspan='2'>Patent/ Publication</th>
</tr>
<tr>
 <th>Principal</th>
 <th>Co-Investigator</th>
 <th>From</th>
 <th>To</th>
</tr>";
    while($row1 = $result1->fetch_assoc()) {
        //echo "id: " . $row["eid"]. " - Name: " . $row["tfname"]. " " . $row["tlname"]. "<br>";
        
echo "<tr>";

  echo "<td>" . $row1['Project_title'] . "</td>";

  echo "<td>" . $row1['principal'] . "</td>";

  echo "<td>" . $row1['co_invest'] . "</td>";
  echo "<td>" . $row1['duration_from'] . "</td>";
  echo "<td>" . $row1['duration_to'] . "</td>";
  echo "<td>" . $row1['project_cost'] . "</td>";
  echo "<td>" . $row1['amount'] . "</td>";
  echo "<td>" . $row1['grant_type'] . "</td>";
  echo "<td>" . $row1['funding'] . "</td>";
  echo "<td>" . $row1['patents_publication'] . "</td>";

  echo "</tr>";
    }
    echo "</table>";
} else {
    echo "R&D INFORMATION NOT YET FILLED";
}


?>
</body>
</html>